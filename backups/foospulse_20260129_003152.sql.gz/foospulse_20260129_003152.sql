--
-- PostgreSQL database dump
--

\restrict UTOKPyfNgzfBUwxw72FKbScSGtrS3dpMLLyT4sVtlnLpugghozPvZfYFu9wNgt0

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: foospulse
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO foospulse;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: foospulse
--

COMMENT ON SCHEMA public IS '';


--
-- Name: artifactstatus; Type: TYPE; Schema: public; Owner: foospulse
--

CREATE TYPE public.artifactstatus AS ENUM (
    'queued',
    'running',
    'done',
    'failed'
);


ALTER TYPE public.artifactstatus OWNER TO foospulse;

--
-- Name: eventtype; Type: TYPE; Schema: public; Owner: foospulse
--

CREATE TYPE public.eventtype AS ENUM (
    'gamelle',
    'lob'
);


ALTER TYPE public.eventtype OWNER TO foospulse;

--
-- Name: leaguevisibility; Type: TYPE; Schema: public; Owner: foospulse
--

CREATE TYPE public.leaguevisibility AS ENUM (
    'private',
    'public'
);


ALTER TYPE public.leaguevisibility OWNER TO foospulse;

--
-- Name: matchmode; Type: TYPE; Schema: public; Owner: foospulse
--

CREATE TYPE public.matchmode AS ENUM (
    '1v1',
    '2v2'
);


ALTER TYPE public.matchmode OWNER TO foospulse;

--
-- Name: matchstatus; Type: TYPE; Schema: public; Owner: foospulse
--

CREATE TYPE public.matchstatus AS ENUM (
    'valid',
    'void'
);


ALTER TYPE public.matchstatus OWNER TO foospulse;

--
-- Name: memberrole; Type: TYPE; Schema: public; Owner: foospulse
--

CREATE TYPE public.memberrole AS ENUM (
    'owner',
    'admin',
    'member'
);


ALTER TYPE public.memberrole OWNER TO foospulse;

--
-- Name: memberstatus; Type: TYPE; Schema: public; Owner: foospulse
--

CREATE TYPE public.memberstatus AS ENUM (
    'active',
    'invited',
    'removed'
);


ALTER TYPE public.memberstatus OWNER TO foospulse;

--
-- Name: playerposition; Type: TYPE; Schema: public; Owner: foospulse
--

CREATE TYPE public.playerposition AS ENUM (
    'attack',
    'defense'
);


ALTER TYPE public.playerposition OWNER TO foospulse;

--
-- Name: seasonstatus; Type: TYPE; Schema: public; Owner: foospulse
--

CREATE TYPE public.seasonstatus AS ENUM (
    'active',
    'archived'
);


ALTER TYPE public.seasonstatus OWNER TO foospulse;

--
-- Name: team; Type: TYPE; Schema: public; Owner: foospulse
--

CREATE TYPE public.team AS ENUM (
    'A',
    'B'
);


ALTER TYPE public.team OWNER TO foospulse;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: foospulse
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO foospulse;

--
-- Name: artifacts; Type: TABLE; Schema: public; Owner: foospulse
--

CREATE TABLE public.artifacts (
    id uuid NOT NULL,
    league_id uuid NOT NULL,
    season_id uuid NOT NULL,
    generator character varying(50) NOT NULL,
    artifact_set_name character varying(50) NOT NULL,
    status public.artifactstatus NOT NULL,
    run_id character varying(50) NOT NULL,
    output_path character varying(500),
    manifest_json jsonb,
    source_hash character varying(64),
    created_by_player_id uuid,
    created_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    error_message text
);


ALTER TABLE public.artifacts OWNER TO foospulse;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: foospulse
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    action character varying(50) NOT NULL,
    actor_user_id uuid,
    actor_player_id uuid,
    entity_type character varying(50) NOT NULL,
    entity_id uuid NOT NULL,
    league_id uuid,
    payload_json jsonb,
    description text
);


ALTER TABLE public.audit_logs OWNER TO foospulse;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: foospulse
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO foospulse;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: foospulse
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: league_members; Type: TABLE; Schema: public; Owner: foospulse
--

CREATE TABLE public.league_members (
    id uuid NOT NULL,
    league_id uuid NOT NULL,
    user_id uuid,
    player_id uuid,
    role public.memberrole NOT NULL,
    status public.memberstatus NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.league_members OWNER TO foospulse;

--
-- Name: leagues; Type: TABLE; Schema: public; Owner: foospulse
--

CREATE TABLE public.leagues (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(50) NOT NULL,
    timezone character varying(50) NOT NULL,
    visibility public.leaguevisibility NOT NULL,
    created_by_user_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    settings jsonb DEFAULT '{"show_shame_stats": true, "show_gamelles_board": true}'::jsonb NOT NULL,
    invite_code character varying(20)
);


ALTER TABLE public.leagues OWNER TO foospulse;

--
-- Name: live_match_session_events; Type: TABLE; Schema: public; Owner: foospulse
--

CREATE TABLE public.live_match_session_events (
    id uuid NOT NULL,
    session_id uuid NOT NULL,
    event_type character varying(20) NOT NULL,
    team character varying(1),
    by_player_id uuid,
    against_player_id uuid,
    custom_type character varying(50),
    metadata_json jsonb,
    recorded_at timestamp with time zone DEFAULT now() NOT NULL,
    recorded_by_user_id uuid,
    undone_at timestamp with time zone,
    elapsed_seconds integer
);


ALTER TABLE public.live_match_session_events OWNER TO foospulse;

--
-- Name: live_match_session_players; Type: TABLE; Schema: public; Owner: foospulse
--

CREATE TABLE public.live_match_session_players (
    id uuid NOT NULL,
    session_id uuid NOT NULL,
    player_id uuid NOT NULL,
    team character varying(1) NOT NULL,
    "position" character varying(10) NOT NULL
);


ALTER TABLE public.live_match_session_players OWNER TO foospulse;

--
-- Name: live_match_sessions; Type: TABLE; Schema: public; Owner: foospulse
--

CREATE TABLE public.live_match_sessions (
    id uuid NOT NULL,
    league_id uuid NOT NULL,
    season_id uuid NOT NULL,
    share_token character varying(32) NOT NULL,
    scorer_secret character varying(32),
    mode character varying(10) NOT NULL,
    status character varying(20) DEFAULT 'waiting'::character varying NOT NULL,
    team_a_score integer DEFAULT 0 NOT NULL,
    team_b_score integer DEFAULT 0 NOT NULL,
    created_by_user_id uuid NOT NULL,
    started_at timestamp with time zone,
    ended_at timestamp with time zone,
    finalized_match_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.live_match_sessions OWNER TO foospulse;

--
-- Name: match_events; Type: TABLE; Schema: public; Owner: foospulse
--

CREATE TABLE public.match_events (
    id uuid NOT NULL,
    match_id uuid NOT NULL,
    event_type public.eventtype NOT NULL,
    against_player_id uuid NOT NULL,
    by_player_id uuid,
    count integer NOT NULL
);


ALTER TABLE public.match_events OWNER TO foospulse;

--
-- Name: match_players; Type: TABLE; Schema: public; Owner: foospulse
--

CREATE TABLE public.match_players (
    id uuid NOT NULL,
    match_id uuid NOT NULL,
    player_id uuid NOT NULL,
    team public.team NOT NULL,
    "position" public.playerposition NOT NULL,
    is_captain boolean NOT NULL
);


ALTER TABLE public.match_players OWNER TO foospulse;

--
-- Name: matches; Type: TABLE; Schema: public; Owner: foospulse
--

CREATE TABLE public.matches (
    id uuid NOT NULL,
    league_id uuid NOT NULL,
    season_id uuid NOT NULL,
    mode public.matchmode NOT NULL,
    team_a_score integer NOT NULL,
    team_b_score integer NOT NULL,
    played_at timestamp with time zone NOT NULL,
    created_by_player_id uuid,
    status public.matchstatus NOT NULL,
    void_reason text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.matches OWNER TO foospulse;

--
-- Name: players; Type: TABLE; Schema: public; Owner: foospulse
--

CREATE TABLE public.players (
    id uuid NOT NULL,
    league_id uuid NOT NULL,
    user_id uuid,
    nickname character varying(50) NOT NULL,
    avatar_url character varying(500),
    is_guest boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.players OWNER TO foospulse;

--
-- Name: rating_snapshots; Type: TABLE; Schema: public; Owner: foospulse
--

CREATE TABLE public.rating_snapshots (
    id uuid NOT NULL,
    league_id uuid NOT NULL,
    season_id uuid NOT NULL,
    player_id uuid NOT NULL,
    mode character varying(10) NOT NULL,
    rating integer NOT NULL,
    as_of_match_id uuid NOT NULL,
    computed_at timestamp with time zone NOT NULL
);


ALTER TABLE public.rating_snapshots OWNER TO foospulse;

--
-- Name: seasons; Type: TABLE; Schema: public; Owner: foospulse
--

CREATE TABLE public.seasons (
    id uuid NOT NULL,
    league_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    status public.seasonstatus NOT NULL,
    starts_at date NOT NULL,
    ends_at date,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.seasons OWNER TO foospulse;

--
-- Name: stats_snapshots; Type: TABLE; Schema: public; Owner: foospulse
--

CREATE TABLE public.stats_snapshots (
    id uuid NOT NULL,
    league_id uuid NOT NULL,
    season_id uuid NOT NULL,
    snapshot_type character varying(50) NOT NULL,
    version character varying(20) NOT NULL,
    data_json jsonb NOT NULL,
    computed_at timestamp with time zone NOT NULL,
    source_hash character varying(64) NOT NULL
);


ALTER TABLE public.stats_snapshots OWNER TO foospulse;

--
-- Name: users; Type: TABLE; Schema: public; Owner: foospulse
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    display_name character varying(100) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.users OWNER TO foospulse;

--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: foospulse
--

COPY public.alembic_version (version_num) FROM stdin;
007
\.


--
-- Data for Name: artifacts; Type: TABLE DATA; Schema: public; Owner: foospulse
--

COPY public.artifacts (id, league_id, season_id, generator, artifact_set_name, status, run_id, output_path, manifest_json, source_hash, created_by_player_id, created_at, completed_at, error_message) FROM stdin;
d02835ee-65ce-4b07-8d41-647bbe6b49ba	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	deterministic_v1	league_report	queued	01KG07M1PQM6BGPS74JK48JT1E	\N	\N	\N	0bca3ab6-6f5f-4ba4-8525-b958523548e0	2026-01-27 17:22:03.104249+00	\N	\N
25c1cdfc-932f-407d-9eec-5192a8e66d22	5c900756-8c86-476c-afaf-5115705dccd8	92d9eeac-f264-4b8f-8b3b-990a929af9f3	deterministic_v1	league_report	queued	01KG39YK61VZTBSJH6CMJ5P0DR	\N	\N	\N	3fa970ed-06c8-4856-bd6a-bdcbc8afde04	2026-01-28 22:00:29.12434+00	\N	\N
0829891f-2d6a-4e6f-8632-5236bebd8d88	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	deterministic_v1	league_report	done	01KG3AQQ0ZFMK0T8GYTHF04KJ1	/data/artifacts/office-champions/e3d617ad-e920-419f-a3e5-6e0b4de453d6/01KG3AQQ0ZFMK0T8GYTHF04KJ1	{"files": [{"sha256": "df8585196b36a41df6eff4c48e1ee975935b38143d9382a8876e7e32724e7b45", "filename": "stats.json", "size_bytes": 15836}, {"sha256": "d75bcb0927ec63962ed8839b78f09a23f0a1595bdcc23236d33372053e616335", "filename": "leaderboards.csv", "size_bytes": 3297}, {"sha256": "7494a4b48fb4ac4ba501aff8e54d41ff990eb7bca1ad4b9fa58874cb13baadc0", "filename": "synergy_matrix.csv", "size_bytes": 1783}, {"sha256": "32eb76d24a275a72d8c0f73e76abc77e13cfc8a1e3bf16482fd5f2b8e328a025", "filename": "matchups.csv", "size_bytes": 366}, {"sha256": "e30aa8adce815d6d5ed05fb1d0be714cd0b6f076c64cf6d1f99db693a2380037", "filename": "league_digest.md", "size_bytes": 1609}], "generator": "deterministic_v1", "source_hash": "3295ad848a862e75b5bf96b97e8350868e3c50f481c46ddbb1556c151a67d0f3", "generated_at": "2026-01-28T22:14:12.447653"}	3295ad848a862e75b5bf96b97e8350868e3c50f481c46ddbb1556c151a67d0f3	0bca3ab6-6f5f-4ba4-8525-b958523548e0	2026-01-28 22:14:12.260159+00	2026-01-28 22:14:12.454125+00	\N
4b991dfe-45a3-49a7-894f-62b484e2089f	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	deterministic_v1	league_report	done	01KG3CC7B7CDZS514T4HDTWBDC	/data/artifacts/office-champions/e3d617ad-e920-419f-a3e5-6e0b4de453d6/01KG3CC7B7CDZS514T4HDTWBDC	{"files": [{"sha256": "cf9e7744b94d4c395ebf3230c620d8202984fbeb6080993bafe515fde8e474fa", "filename": "stats.json", "size_bytes": 15836}, {"sha256": "d75bcb0927ec63962ed8839b78f09a23f0a1595bdcc23236d33372053e616335", "filename": "leaderboards.csv", "size_bytes": 3297}, {"sha256": "7494a4b48fb4ac4ba501aff8e54d41ff990eb7bca1ad4b9fa58874cb13baadc0", "filename": "synergy_matrix.csv", "size_bytes": 1783}, {"sha256": "32eb76d24a275a72d8c0f73e76abc77e13cfc8a1e3bf16482fd5f2b8e328a025", "filename": "matchups.csv", "size_bytes": 366}, {"sha256": "8375cd757c9e929c378166255b38d29cf96e99352f504dee2042fe907ad3a34d", "filename": "league_digest.md", "size_bytes": 1609}], "generator": "deterministic_v1", "source_hash": "3295ad848a862e75b5bf96b97e8350868e3c50f481c46ddbb1556c151a67d0f3", "generated_at": "2026-01-28T22:42:54.727361"}	3295ad848a862e75b5bf96b97e8350868e3c50f481c46ddbb1556c151a67d0f3	0bca3ab6-6f5f-4ba4-8525-b958523548e0	2026-01-28 22:42:52.94255+00	2026-01-28 22:42:54.737208+00	\N
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: foospulse
--

COPY public.audit_logs (id, created_at, action, actor_user_id, actor_player_id, entity_type, entity_id, league_id, payload_json, description) FROM stdin;
1	2026-01-28 22:00:29.128152+00	artifact_start	9abc693e-974d-4649-b816-fac0290441d2	3fa970ed-06c8-4856-bd6a-bdcbc8afde04	artifact	25c1cdfc-932f-407d-9eec-5192a8e66d22	5c900756-8c86-476c-afaf-5115705dccd8	{"artifact_type": "league_report"}	Artifact generation started: league_report
2	2026-01-28 22:13:08.067458+00	match_create	9abc693e-974d-4649-b816-fac0290441d2	3fa970ed-06c8-4856-bd6a-bdcbc8afde04	match	4a904595-d7e5-4cfc-bf97-4e06471a7799	5c900756-8c86-476c-afaf-5115705dccd8	{"mode": "1v1", "player_count": 2, "team_a_score": 5, "team_b_score": 4}	Match created: 1v1 5-4
3	2026-01-28 22:14:12.267828+00	artifact_start	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	0bca3ab6-6f5f-4ba4-8525-b958523548e0	artifact	0829891f-2d6a-4e6f-8632-5236bebd8d88	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	{"artifact_type": "league_report"}	Artifact generation started: league_report
4	2026-01-28 22:14:12.454162+00	artifact_complete	\N	\N	artifact	0829891f-2d6a-4e6f-8632-5236bebd8d88	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	{"files": ["stats.json", "leaderboards.csv", "synergy_matrix.csv", "matchups.csv", "league_digest.md"], "source_hash": "3295ad848a862e75b5bf96b97e8350868e3c50f481c46ddbb1556c151a67d0f3"}	Artifact generation completed: 5 files
5	2026-01-28 22:42:52.990361+00	artifact_start	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	0bca3ab6-6f5f-4ba4-8525-b958523548e0	artifact	4b991dfe-45a3-49a7-894f-62b484e2089f	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	{"artifact_type": "league_report"}	Artifact generation started: league_report
6	2026-01-28 22:42:54.737504+00	artifact_complete	\N	\N	artifact	4b991dfe-45a3-49a7-894f-62b484e2089f	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	{"files": ["stats.json", "leaderboards.csv", "synergy_matrix.csv", "matchups.csv", "league_digest.md"], "source_hash": "3295ad848a862e75b5bf96b97e8350868e3c50f481c46ddbb1556c151a67d0f3"}	Artifact generation completed: 5 files
\.


--
-- Data for Name: league_members; Type: TABLE DATA; Schema: public; Owner: foospulse
--

COPY public.league_members (id, league_id, user_id, player_id, role, status, created_at) FROM stdin;
fea66634-9f33-423a-88fa-01e105eb3b43	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	0bca3ab6-6f5f-4ba4-8525-b958523548e0	owner	active	2026-01-27 15:55:03.448725+00
a38b7090-e8af-4d1c-8b87-5f4145112d60	5c900756-8c86-476c-afaf-5115705dccd8	9abc693e-974d-4649-b816-fac0290441d2	3fa970ed-06c8-4856-bd6a-bdcbc8afde04	owner	active	2026-01-28 19:37:59.98048+00
\.


--
-- Data for Name: leagues; Type: TABLE DATA; Schema: public; Owner: foospulse
--

COPY public.leagues (id, name, slug, timezone, visibility, created_by_user_id, created_at, updated_at, settings, invite_code) FROM stdin;
4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	Office Champions	office-champions	Europe/Paris	private	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	2026-01-27 15:55:03.214274+00	2026-01-27 15:55:03.214279+00	{"show_shame_stats": true, "show_gamelles_board": true}	Rq4L7_gu
5c900756-8c86-476c-afaf-5115705dccd8	Igonogo	igonogo	Europe/Paris	private	9abc693e-974d-4649-b816-fac0290441d2	2026-01-28 19:37:59.964292+00	2026-01-28 19:37:59.964295+00	{"show_shame_stats": true, "show_gamelles_board": true}	az69gRQH
\.


--
-- Data for Name: live_match_session_events; Type: TABLE DATA; Schema: public; Owner: foospulse
--

COPY public.live_match_session_events (id, session_id, event_type, team, by_player_id, against_player_id, custom_type, metadata_json, recorded_at, recorded_by_user_id, undone_at, elapsed_seconds) FROM stdin;
bfb6b157-bfea-49b8-98e6-8283822507f8	3fa25f1c-5577-46ee-8351-a7368e9b96c3	goal	A	\N	\N	\N	null	2026-01-28 12:46:59.359555+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	\N
5786e42d-c179-4212-bec3-e76ebf04665a	3fa25f1c-5577-46ee-8351-a7368e9b96c3	goal	A	\N	\N	\N	null	2026-01-28 12:47:01.328608+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	\N
273243fe-9617-46ca-837a-37cca2aa8fd4	3fa25f1c-5577-46ee-8351-a7368e9b96c3	goal	B	\N	\N	\N	null	2026-01-28 12:47:02.667914+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	\N
0bb408a7-804f-4176-8377-8a23fe366409	3fa25f1c-5577-46ee-8351-a7368e9b96c3	goal	B	\N	\N	\N	null	2026-01-28 12:47:07.852487+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	\N
88fd4f5f-d175-408a-ba83-dc91861678ed	3fa25f1c-5577-46ee-8351-a7368e9b96c3	gamelle	\N	\N	fc83e69d-2909-4934-9ac2-dc0c91524bdb	\N	null	2026-01-28 12:48:27.486109+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	\N
2c2692b5-7fca-40d8-98a0-da794c6361bf	3fa25f1c-5577-46ee-8351-a7368e9b96c3	gamelle	\N	\N	a435c102-0bdc-449e-ad56-727e42975cb7	\N	null	2026-01-28 12:48:28.63352+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	\N
9ee529ac-7d86-4735-87bb-ae65afe46b9a	3fa25f1c-5577-46ee-8351-a7368e9b96c3	goal	B	\N	\N	\N	null	2026-01-28 12:48:29.96259+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	\N
1a2bc0bb-941e-496f-9727-ee79cbb41aa9	3fa25f1c-5577-46ee-8351-a7368e9b96c3	goal	A	\N	\N	\N	null	2026-01-28 12:48:30.954864+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	\N
51442b33-8b36-424d-9725-c46c7fd1bb16	3fa25f1c-5577-46ee-8351-a7368e9b96c3	gamelle	\N	\N	a435c102-0bdc-449e-ad56-727e42975cb7	\N	null	2026-01-28 12:48:31.60971+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	\N
2d4b8ce5-60f1-4c14-8b72-2ec1aff6578b	70d50640-1159-461b-8e35-b22662968ee2	goal	A	\N	\N	\N	null	2026-01-28 13:21:59.426894+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	10
01b64179-5d32-41a4-b2d5-6f8a9ca6fdea	70d50640-1159-461b-8e35-b22662968ee2	goal	A	\N	\N	\N	null	2026-01-28 13:22:02.347579+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	13
7543af60-d871-418c-844a-1ede611e067c	70d50640-1159-461b-8e35-b22662968ee2	goal	B	\N	\N	\N	null	2026-01-28 13:22:04.236701+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	15
d253cdf2-a0c8-4ee6-9582-98f7f4f5dc03	70d50640-1159-461b-8e35-b22662968ee2	goal	A	\N	\N	\N	null	2026-01-28 13:22:09.02316+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	20
bcf620aa-5e43-4b2d-af5f-7a128dedd9e3	70d50640-1159-461b-8e35-b22662968ee2	gamelle	A	\N	2aebbb9b-7461-4489-a135-6f61c9bf9643	\N	null	2026-01-28 13:22:14.740157+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	26
a47b42a1-0687-4a98-8a64-820a74dba951	70d50640-1159-461b-8e35-b22662968ee2	gamelle	A	\N	2aebbb9b-7461-4489-a135-6f61c9bf9643	\N	null	2026-01-28 13:22:19.294898+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	30
90879d1b-d756-48be-8f50-bc1c8cb994fc	70d50640-1159-461b-8e35-b22662968ee2	cage	A	\N	\N	\N	null	2026-01-28 13:22:25.158162+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	36
1aaf4521-93b0-4a86-8458-feb272d023fe	70d50640-1159-461b-8e35-b22662968ee2	goal	A	\N	\N	\N	null	2026-01-28 13:22:28.166979+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	39
cbc31baf-a121-4a25-bead-e1a7a3d00f8d	70d50640-1159-461b-8e35-b22662968ee2	goal	A	\N	\N	\N	null	2026-01-28 13:22:28.30652+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	39
e7f690ad-8263-4980-a617-553176990d4e	70d50640-1159-461b-8e35-b22662968ee2	goal	A	\N	\N	\N	null	2026-01-28 13:22:28.488501+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	39
9114fc1f-55be-4d72-94b3-629b1775085a	70d50640-1159-461b-8e35-b22662968ee2	goal	A	\N	\N	\N	null	2026-01-28 13:22:28.622901+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	40
80024431-4851-41e9-aad2-a350f6320fe9	70d50640-1159-461b-8e35-b22662968ee2	cage	A	\N	\N	\N	null	2026-01-28 13:22:29.278523+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	40
705a15cd-e878-4747-9117-77b37289e235	70d50640-1159-461b-8e35-b22662968ee2	cage	A	\N	\N	\N	null	2026-01-28 13:22:29.680132+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	41
16ad7e57-8858-4b70-b0fe-b9c8c8b03b37	70d50640-1159-461b-8e35-b22662968ee2	cage	A	\N	\N	\N	null	2026-01-28 13:22:30.127715+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	41
28c2dd9c-801b-4dc8-9000-f13f78e2943b	70d50640-1159-461b-8e35-b22662968ee2	goal	A	\N	\N	\N	null	2026-01-28 13:25:48.691675+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	240
fb703164-6154-4338-bc4f-b6536d48f21a	70d50640-1159-461b-8e35-b22662968ee2	goal	A	\N	\N	\N	null	2026-01-28 13:25:48.808023+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	240
9026d142-6d2e-4884-a6b0-128f2b14fd69	70d50640-1159-461b-8e35-b22662968ee2	goal	A	\N	\N	\N	null	2026-01-28 13:25:48.962445+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	240
a702883a-4df0-4424-af19-ae813239624e	70d50640-1159-461b-8e35-b22662968ee2	goal	A	\N	\N	\N	null	2026-01-28 13:25:49.103825+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	240
cfbcf324-0670-4b40-801c-1a1eeb1c5877	70d50640-1159-461b-8e35-b22662968ee2	goal	B	\N	\N	\N	null	2026-01-28 13:25:49.508735+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	240
3b9e4448-d357-472d-ac21-70981e480e13	70d50640-1159-461b-8e35-b22662968ee2	cage	B	\N	\N	\N	null	2026-01-28 13:25:50.537723+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	241
ed3ab56e-72ce-4129-b5f7-ad2f5915f220	70d50640-1159-461b-8e35-b22662968ee2	cage	B	\N	\N	\N	null	2026-01-28 13:25:51.001268+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	242
eeaaaa76-5fb9-4e02-a932-2d171009e141	70d50640-1159-461b-8e35-b22662968ee2	goal	A	\N	\N	\N	null	2026-01-28 13:28:39.778821+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	411
8f06b855-4224-4b01-a7f1-b8ee1db8bf96	70d50640-1159-461b-8e35-b22662968ee2	goal	B	\N	\N	\N	null	2026-01-28 13:28:40.734956+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	412
5fefe098-a0d6-4588-93f9-f350f224e1b9	c8aab6af-2dc0-4c1d-bfd1-8f77332c0c96	goal	A	\N	\N	\N	null	2026-01-28 13:49:23.068348+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	0
fc52fc2b-50f1-425a-845a-27b16c4e7772	c8aab6af-2dc0-4c1d-bfd1-8f77332c0c96	goal	A	\N	\N	\N	null	2026-01-28 13:49:23.49981+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	1
47d164e2-910d-40b4-ac96-40b84228099a	c8aab6af-2dc0-4c1d-bfd1-8f77332c0c96	goal	A	\N	\N	\N	null	2026-01-28 13:49:23.653902+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	1
a609b00a-f0ba-47da-a311-c80b2d3beae7	c8aab6af-2dc0-4c1d-bfd1-8f77332c0c96	goal	A	\N	\N	\N	null	2026-01-28 13:49:23.79479+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	1
63e34f42-c721-48c4-be33-9e7dcb87b4c7	c8aab6af-2dc0-4c1d-bfd1-8f77332c0c96	goal	B	\N	\N	\N	null	2026-01-28 13:49:28.081359+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	5
324f20a7-c54d-426e-886f-e708d394a75b	c8aab6af-2dc0-4c1d-bfd1-8f77332c0c96	goal	A	\N	\N	\N	null	2026-01-28 13:49:29.55756+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	7
bc09a832-8088-4c08-b4d5-fff73ff260f0	c8aab6af-2dc0-4c1d-bfd1-8f77332c0c96	goal	B	\N	\N	\N	null	2026-01-28 13:49:30.03827+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	7
9b2368e8-8509-41c5-8c50-c2fd76ffaea9	c8aab6af-2dc0-4c1d-bfd1-8f77332c0c96	goal	B	\N	\N	\N	null	2026-01-28 13:49:30.137918+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	7
afcfd764-2214-47c1-9968-27215d111d2b	c8aab6af-2dc0-4c1d-bfd1-8f77332c0c96	goal	B	\N	\N	\N	null	2026-01-28 13:49:30.307341+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	7
a9de33c5-732e-456b-b139-69aeed47c38a	c8aab6af-2dc0-4c1d-bfd1-8f77332c0c96	goal	B	\N	\N	\N	null	2026-01-28 13:49:30.485803+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	8
ea41a4de-6f7b-43d5-aeb2-ac3eb3ec0ad1	c8aab6af-2dc0-4c1d-bfd1-8f77332c0c96	goal	A	\N	\N	\N	null	2026-01-28 13:53:54.807148+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	271
691be2f6-f9ad-4a09-b5f6-1b971d2461b6	c8aab6af-2dc0-4c1d-bfd1-8f77332c0c96	goal	A	\N	\N	\N	null	2026-01-28 13:53:55.174422+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	272
695c5d45-3205-4d2e-86cc-25ca499f5611	c8aab6af-2dc0-4c1d-bfd1-8f77332c0c96	goal	A	\N	\N	\N	null	2026-01-28 14:17:17.071361+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	1674
08360e1e-0b2a-44a3-aa7d-af14f1160c16	c8aab6af-2dc0-4c1d-bfd1-8f77332c0c96	goal	A	\N	\N	\N	null	2026-01-28 14:17:17.760026+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	1675
0615519f-a576-4877-ba0e-5f5162239d34	32f8cc31-1b5e-4ce8-aa69-6b3bdd75d3c6	goal	B	\N	\N	\N	null	2026-01-28 14:18:35.036155+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	1
697406b8-dabf-4214-a663-9f81045565c4	32f8cc31-1b5e-4ce8-aa69-6b3bdd75d3c6	goal	B	\N	\N	\N	null	2026-01-28 14:18:36.10427+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	2
519d05af-aa47-4036-ab7c-38c7a412219b	3e94afc7-5535-4542-b11b-506084e099e6	goal	A	\N	\N	\N	null	2026-01-28 14:19:47.827099+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	10
06190920-7691-4a8d-8c0f-80e34aee6b44	32f8cc31-1b5e-4ce8-aa69-6b3bdd75d3c6	goal	A	\N	\N	\N	null	2026-01-28 14:19:53.772205+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	80
26b46255-18ef-4bad-8a48-a93d54338840	32f8cc31-1b5e-4ce8-aa69-6b3bdd75d3c6	goal	A	\N	\N	\N	null	2026-01-28 14:19:53.96473+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	80
08620e3e-4d5e-45ba-a0a0-72bc9ebdf71e	32f8cc31-1b5e-4ce8-aa69-6b3bdd75d3c6	goal	A	\N	\N	\N	null	2026-01-28 14:19:54.114772+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	80
88416e42-661b-4f3a-bfef-a3a8cdcf51bc	32f8cc31-1b5e-4ce8-aa69-6b3bdd75d3c6	gamellized	A	\N	\N	\N	null	2026-01-28 14:20:02.976453+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	89
2511b14d-f931-4316-a62d-9fb041ceeb7c	32f8cc31-1b5e-4ce8-aa69-6b3bdd75d3c6	gamellized	A	\N	\N	\N	null	2026-01-28 14:20:03.492954+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	89
24b6b906-9402-45f6-8f6a-3a0cfd5af35d	32f8cc31-1b5e-4ce8-aa69-6b3bdd75d3c6	gamellized	A	\N	\N	\N	null	2026-01-28 14:20:03.655338+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	89
b67d04a3-116f-4545-9227-d3bfd005b401	32f8cc31-1b5e-4ce8-aa69-6b3bdd75d3c6	lobbed	A	\N	\N	\N	null	2026-01-28 14:20:04.430145+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	90
b62fa640-ea93-465f-96dc-d2350a71195d	4c987b67-27c6-498d-bae3-25b66d18e4ba	gamellized	A	\N	\N	\N	null	2026-01-28 14:20:39.001723+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	0
fe5208f6-a5a7-41d4-95c4-3e06fd21587d	4c987b67-27c6-498d-bae3-25b66d18e4ba	gamellized	A	\N	\N	\N	null	2026-01-28 14:20:39.302059+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	1
2e2d559d-0d62-4d32-b59e-fc807c526a73	4c987b67-27c6-498d-bae3-25b66d18e4ba	gamellized	A	\N	\N	\N	null	2026-01-28 14:20:39.497918+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	1
8d9963d5-4e55-44b9-979d-d33c26cedd6b	4c987b67-27c6-498d-bae3-25b66d18e4ba	lobbed	A	\N	\N	\N	null	2026-01-28 14:20:40.484142+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	2
533e08da-e30b-4a62-b6e2-ff18fb449113	4c987b67-27c6-498d-bae3-25b66d18e4ba	lobbed	A	\N	\N	\N	null	2026-01-28 14:20:40.893333+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	2
a428e284-992d-4878-b6a0-cbc0f11f03f0	4c987b67-27c6-498d-bae3-25b66d18e4ba	lobbed	A	\N	\N	\N	null	2026-01-28 14:20:41.11463+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	2
f339d47e-12ae-4d6e-b5b1-9d0cac536293	4c987b67-27c6-498d-bae3-25b66d18e4ba	lobbed	A	\N	\N	\N	null	2026-01-28 14:20:41.266083+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	2
e21879d7-a036-4aee-a53f-62a55477488d	4c987b67-27c6-498d-bae3-25b66d18e4ba	lobbed	A	\N	\N	\N	null	2026-01-28 14:20:41.679299+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	3
c07b3bdc-3dbe-4ec1-a5da-b748b8d10862	4c987b67-27c6-498d-bae3-25b66d18e4ba	gamellized	B	\N	\N	\N	null	2026-01-28 14:20:43.015672+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	4
173cb5f2-0a33-4e82-8ccb-81ab42295151	4c987b67-27c6-498d-bae3-25b66d18e4ba	gamellized	B	\N	\N	\N	null	2026-01-28 14:20:43.190281+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	4
bb8bd544-193f-4528-aff1-fa3fe55c9619	4c987b67-27c6-498d-bae3-25b66d18e4ba	gamellized	B	\N	\N	\N	null	2026-01-28 14:20:43.330939+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	5
041384c5-4912-4bd5-b59f-9574b70be58e	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:20:44.021262+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	5
3dc3998c-7f7b-48f5-9c73-29ed430819f3	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:20:44.150631+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	5
80be3686-bbb0-4286-aab9-1fce5efdadf2	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:20:44.890336+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	6
c844387c-27c8-497c-baff-652e80d4612c	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:20:45.705177+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	7
6eee157b-2d32-4c71-b6c9-6f88ef270632	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:20:46.182102+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	7
128d61cd-ace4-4995-9bad-0debb892d917	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:20:46.674028+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	8
6d16dad4-20e9-40ea-9ed9-ef8fad170c9b	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:20:47.14782+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	8
7d161dc2-7d10-46f3-9cbf-8c5e529012a8	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:20:47.63256+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	9
fbc91bcf-6e60-439b-90a2-d17da040aa33	4c987b67-27c6-498d-bae3-25b66d18e4ba	gamellized	B	\N	\N	\N	null	2026-01-28 14:20:48.585594+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	10
bb7ea967-8d08-404f-8881-12d0cde57294	4c987b67-27c6-498d-bae3-25b66d18e4ba	lobbed	B	\N	\N	\N	null	2026-01-28 14:20:51.257901+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	12
e686ec58-3251-4f79-af64-ca7c79bf5f33	eb7e1611-7352-48a1-935e-d1ea67df662a	gamellized	A	\N	\N	\N	null	2026-01-28 14:20:55.204941+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	20
bfb500bb-55e0-4f7b-a51c-c17ec72213c7	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:20:44.326286+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	6
f486d293-5e78-404f-95a2-78520ff1766e	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:20:45.029802+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	6
b7e40d2d-1e84-4f17-ac26-d741ee28a288	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:20:45.863551+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	7
6a655e07-3eda-495c-be7d-71812aea0a9c	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:20:46.347132+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	8
7e957340-0ced-4e80-b54b-2761fbee9178	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:20:46.821446+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	8
0153a4ec-520e-4516-a700-c69a1545f9c5	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:20:47.309767+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	9
a539f4b5-c348-43b0-b47a-fbe0831abb83	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:20:47.772148+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	9
22d5c34b-6629-4aeb-a68b-bc09befdc95d	4c987b67-27c6-498d-bae3-25b66d18e4ba	gamellized	B	\N	\N	\N	null	2026-01-28 14:20:49.10331+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	10
358aaf28-81f1-4b1f-a49b-a95d554cd96e	4c987b67-27c6-498d-bae3-25b66d18e4ba	lobbed	B	\N	\N	\N	null	2026-01-28 14:20:51.573936+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	13
61bb916c-2b1c-4847-96a4-d2336d3a6a16	eb7e1611-7352-48a1-935e-d1ea67df662a	goal	A	\N	\N	\N	null	2026-01-28 14:20:55.175542+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	10
912601f7-7df4-4a7d-ae07-ac566be13b37	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:20:44.487094+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	6
45a9714c-9f03-4dab-9741-07a40b721576	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:20:45.18485+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	6
9835d5d5-5781-4c19-b58e-678ecc9aa5ae	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:20:46.032613+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	7
fa7caac4-3329-41f6-853c-1dbb7706c5b7	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:20:46.505342+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	8
4ed06834-5577-4c69-a5be-8c2f8c3f5b4e	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:20:46.980038+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	8
13cdd1a0-8919-4289-84e4-aff004d437c4	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:20:47.470102+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	9
51700a0e-e8c2-4527-b356-fe6ac2b7c0d5	4c987b67-27c6-498d-bae3-25b66d18e4ba	gamellized	B	\N	\N	\N	null	2026-01-28 14:20:48.561148+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	10
d1aad2de-30ba-4f2d-97cc-c8f98545af3e	4c987b67-27c6-498d-bae3-25b66d18e4ba	gamellized	B	\N	\N	\N	null	2026-01-28 14:20:49.815397+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	11
df61e790-7263-4da4-a4ba-745b91ae57de	4c987b67-27c6-498d-bae3-25b66d18e4ba	lobbed	B	\N	\N	\N	null	2026-01-28 14:20:52.113063+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	13
e3233612-9ba3-48f5-a897-d91dff70779a	eb7e1611-7352-48a1-935e-d1ea67df662a	lobbed	B	\N	\N	\N	null	2026-01-28 14:20:55.233256+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	30
89ed8dfc-296c-4ad9-a3c7-9ae3178443ef	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:27:39.90814+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	420
4d37a2a1-b798-4c64-943e-d972cbd585ec	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:27:40.028256+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	421
7eda7db7-333e-41aa-b31d-8435a8fc7b39	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:27:40.188227+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	421
c18368a5-ebde-45c0-bc17-2246b91a2f85	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:27:40.337812+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	421
b5bdc879-2609-4a21-abdb-02339144cef8	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:27:40.494217+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	421
359ec779-8793-4bb9-8c68-4cf50bc94804	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:27:40.670553+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	421
250cca47-9e14-482f-89b2-97ca59a05c0d	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:27:40.833761+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	421
bd9deaf2-7575-42c2-9a2c-50f2803a2efc	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:27:40.990825+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	422
76ef457a-fcb8-4ead-9b6f-28700181e67b	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	A	\N	\N	\N	null	2026-01-28 14:27:41.162518+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	422
04e16443-3bca-4f97-8f35-c46b982aed12	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:27:41.535015+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	422
6c543ef0-429b-490f-ab28-d8c5e45897b0	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:27:41.690306+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	422
47c20d16-4c80-4f6b-b67b-a670d1b414f5	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:27:41.845939+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	422
163a7d56-eb96-4120-8d10-377b272b272b	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:27:42.010006+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	423
9e54e499-96f2-4ea0-aa46-a2ea1b3a3133	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:27:42.184654+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	423
5c409de1-3a09-4d05-90e5-c8e4fe4c71a1	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:27:42.345541+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	423
149512f1-6e83-4dde-b5bc-ca3aa2783200	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:27:42.501903+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	423
4f017464-40c1-47e1-9444-ebc3c76ac5d9	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:27:42.671088+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	423
00771313-bc39-42d8-a177-643d29cd1b93	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:27:42.832702+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	423
1611859e-b511-4f38-888d-da244681b013	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:27:42.985179+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	424
d0e995a4-1ab9-4e3d-bc0b-000d9d476da2	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:27:43.156416+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	424
fb4ca82a-2ee1-48b7-9f9a-13767be2b744	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:27:43.328591+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	424
08013571-f3ff-4e5d-bf1a-34e4240fba15	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:27:43.490143+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	424
fa022174-89d2-491a-9475-5a5f11d98260	4c987b67-27c6-498d-bae3-25b66d18e4ba	lobbed	B	\N	\N	\N	null	2026-01-28 14:27:44.2279+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	425
b9ce49a5-f1ca-4709-9d0d-9a4ace7dafa0	4c987b67-27c6-498d-bae3-25b66d18e4ba	gamellized	B	\N	\N	\N	null	2026-01-28 14:27:44.991889+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	426
9a395683-dc26-471b-9913-5120af14ddf1	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:27:45.759487+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	426
0a915236-682d-4518-972f-c74641411f66	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:27:45.894534+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	426
f90ed26c-3d65-43a0-9806-dd67c0fba198	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:27:46.059268+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	427
2414bf93-f381-4d7b-8360-9b1edc2889cc	4c987b67-27c6-498d-bae3-25b66d18e4ba	goal	B	\N	\N	\N	null	2026-01-28 14:27:46.384279+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	427
5008da59-06ea-4732-9246-610ac2fb54f6	c2471429-18ae-4366-93ed-1bc90ffc65f5	goal	A	\N	\N	\N	null	2026-01-28 14:58:51.700858+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	2
01d84a2e-4d34-480b-8e0c-140c4c70c45e	c2471429-18ae-4366-93ed-1bc90ffc65f5	goal	A	\N	\N	\N	null	2026-01-28 14:58:51.86386+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	2
a08dcab6-46a2-47e0-aa5b-ca295bedcc2f	c2471429-18ae-4366-93ed-1bc90ffc65f5	goal	A	\N	\N	\N	null	2026-01-28 14:58:52.036584+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	3
5315bbf3-e8ce-4a5f-97a7-526e509321fd	c2471429-18ae-4366-93ed-1bc90ffc65f5	goal	B	\N	\N	\N	null	2026-01-28 14:58:53.04434+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	4
1b79295f-752e-4529-b0f4-58de0bb82508	c2471429-18ae-4366-93ed-1bc90ffc65f5	gamellized	B	\N	\N	\N	null	2026-01-28 14:58:54.170667+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	5
fb440569-e5e6-4585-84a0-9b9e5d99e81d	c2471429-18ae-4366-93ed-1bc90ffc65f5	gamellized	B	\N	\N	\N	null	2026-01-28 14:58:54.374346+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	5
6a3444ce-4865-43e1-98a6-cb910e86331c	c2471429-18ae-4366-93ed-1bc90ffc65f5	goal	B	\N	\N	\N	null	2026-01-28 14:58:55.187468+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	6
6011a5e8-acea-4511-a8d4-54ca0e1bd181	c2471429-18ae-4366-93ed-1bc90ffc65f5	goal	B	\N	\N	\N	null	2026-01-28 14:58:55.418984+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	6
7327b4e4-540a-4ea6-ab08-133d7a26a734	c2471429-18ae-4366-93ed-1bc90ffc65f5	gamellized	A	\N	\N	\N	null	2026-01-28 14:58:56.321211+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	7
90e7f2b2-aec2-46b2-b47d-5b45bb477815	c2471429-18ae-4366-93ed-1bc90ffc65f5	lobbed	A	\N	\N	\N	null	2026-01-28 14:58:57.72238+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	8
8d210f41-a6ef-403b-8d49-29aa92312d22	c2471429-18ae-4366-93ed-1bc90ffc65f5	goal	A	\N	\N	\N	null	2026-01-28 14:58:58.550637+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	9
03910fff-c5b8-43af-8079-1720f183922e	c2471429-18ae-4366-93ed-1bc90ffc65f5	goal	A	\N	\N	\N	null	2026-01-28 14:58:58.701328+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	9
b29bf7aa-751a-4c2b-a1e3-4d09291bec6e	c2471429-18ae-4366-93ed-1bc90ffc65f5	goal	B	\N	\N	\N	null	2026-01-28 14:58:59.165821+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	10
d92e42da-43d2-4cd9-a240-a1c0cc70dcb4	c2471429-18ae-4366-93ed-1bc90ffc65f5	goal	B	\N	\N	\N	null	2026-01-28 14:58:59.340262+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	10
05f3df2b-9dec-4c75-b688-70d1ab02c9c1	c2471429-18ae-4366-93ed-1bc90ffc65f5	goal	B	\N	\N	\N	null	2026-01-28 14:58:59.612739+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	10
e796f73b-308b-4638-89c6-831852037ad5	c2471429-18ae-4366-93ed-1bc90ffc65f5	goal	A	\N	\N	\N	null	2026-01-28 14:59:00.080512+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	11
2854999c-bc26-4efb-b8c1-a08109fb25dd	c2471429-18ae-4366-93ed-1bc90ffc65f5	goal	A	\N	\N	\N	null	2026-01-28 14:59:00.24813+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	11
6fbae255-2c7e-43da-b787-9e34a2daa23e	c2471429-18ae-4366-93ed-1bc90ffc65f5	lobbed	B	\N	\N	\N	null	2026-01-28 14:59:01.023022+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	12
93e0bc49-1ad1-47e4-a48e-35415ffba251	c2471429-18ae-4366-93ed-1bc90ffc65f5	lobbed	B	\N	\N	\N	null	2026-01-28 14:59:01.19508+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	12
3a02028e-9686-4185-917b-50b7cce8591c	c2471429-18ae-4366-93ed-1bc90ffc65f5	goal	B	\N	\N	\N	null	2026-01-28 14:59:02.090532+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	13
9d8c8165-8dae-4735-97d9-a0d8db15c3f2	c2471429-18ae-4366-93ed-1bc90ffc65f5	goal	B	\N	\N	\N	null	2026-01-28 14:59:02.259794+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	13
166806ae-a725-426d-881f-d49d751b3d1d	c2471429-18ae-4366-93ed-1bc90ffc65f5	goal	B	\N	\N	\N	null	2026-01-28 14:59:02.580219+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	13
43aa3dc2-05d2-4996-8167-25933cd222f8	86b28a3e-94c0-407e-8a3f-f0223fbc09da	gamellized	A	\N	\N	\N	null	2026-01-28 15:00:49.749696+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	0
95adb82b-abda-4a10-b217-793ca2e54a1c	86b28a3e-94c0-407e-8a3f-f0223fbc09da	gamellized	A	\N	\N	\N	null	2026-01-28 15:00:49.95379+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	0
c9c882c8-5481-4b53-b976-1599f8b775fa	86b28a3e-94c0-407e-8a3f-f0223fbc09da	goal	B	\N	\N	\N	null	2026-01-28 15:00:50.43518+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	1
976b1e87-5db7-49ab-bde7-0377913bfc85	86b28a3e-94c0-407e-8a3f-f0223fbc09da	goal	B	\N	\N	\N	null	2026-01-28 15:00:50.590372+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	1
cc295e28-9e3d-4d1d-be69-e36f5114206c	86b28a3e-94c0-407e-8a3f-f0223fbc09da	goal	B	\N	\N	\N	null	2026-01-28 15:00:50.731581+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	1
8a77a678-e14c-430f-94da-12a3ce457aed	86b28a3e-94c0-407e-8a3f-f0223fbc09da	goal	B	\N	\N	\N	null	2026-01-28 15:00:50.891321+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	1
5141c48c-a886-4cc4-b90f-69b51aa40840	86b28a3e-94c0-407e-8a3f-f0223fbc09da	goal	B	\N	\N	\N	null	2026-01-28 15:00:51.05528+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	1
c130567d-dfdb-4204-b0b0-6d3c8f82aaa0	86b28a3e-94c0-407e-8a3f-f0223fbc09da	goal	A	\N	\N	\N	null	2026-01-28 15:00:51.693599+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	2
8b18d9a6-b278-4612-a7e1-39e004c4bc57	86b28a3e-94c0-407e-8a3f-f0223fbc09da	goal	A	\N	\N	\N	null	2026-01-28 15:00:51.843266+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	2
4b71b43d-a114-47b0-a6be-bbbf6ae48237	86b28a3e-94c0-407e-8a3f-f0223fbc09da	gamellized	B	\N	\N	\N	null	2026-01-28 15:00:52.326435+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	3
9a18f1b2-0edc-4986-80b4-807f0f5d5f2e	86b28a3e-94c0-407e-8a3f-f0223fbc09da	goal	A	\N	\N	\N	null	2026-01-28 15:00:53.552359+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	4
8b999e6f-9dcd-4d88-917c-1d9772e8b021	86b28a3e-94c0-407e-8a3f-f0223fbc09da	gamellized	B	\N	\N	\N	null	2026-01-28 15:00:52.486837+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	3
76396db3-3ca6-4e34-9570-41f72baa5e27	86b28a3e-94c0-407e-8a3f-f0223fbc09da	goal	A	\N	\N	\N	null	2026-01-28 15:00:53.695139+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	4
be08d01d-d225-401e-8ff4-53cef893e1d0	86b28a3e-94c0-407e-8a3f-f0223fbc09da	lobbed	B	\N	\N	\N	null	2026-01-28 15:00:52.880209+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	3
c645a831-0abe-4ad3-8122-879f4a6fbf02	86b28a3e-94c0-407e-8a3f-f0223fbc09da	goal	A	\N	\N	\N	null	2026-01-28 15:00:53.844024+00	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	\N	4
0141545a-4c7a-47b1-91a1-02ccc5b2f1d1	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	goal	A	\N	\N	\N	null	2026-01-28 20:03:39.183331+00	9abc693e-974d-4649-b816-fac0290441d2	\N	1
1782841d-248c-4ddb-a765-3a00a3699cc1	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	goal	B	\N	\N	\N	null	2026-01-28 20:03:40.307194+00	9abc693e-974d-4649-b816-fac0290441d2	\N	2
6eb474c2-7ca5-4296-9b82-ee21a8e74d27	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	gamellized	A	\N	\N	\N	null	2026-01-28 20:03:43.21417+00	9abc693e-974d-4649-b816-fac0290441d2	\N	5
ae1ecc25-58b4-45cb-abc6-c04db8aa7297	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	gamellized	A	\N	\N	\N	null	2026-01-28 20:03:43.688273+00	9abc693e-974d-4649-b816-fac0290441d2	\N	6
49991653-daa0-4592-887f-180bd85c670a	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	gamellized	A	\N	\N	\N	null	2026-01-28 20:03:44.259205+00	9abc693e-974d-4649-b816-fac0290441d2	\N	6
07179b3f-693c-44f6-a8c7-93b99a5c5479	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	lobbed	A	\N	\N	\N	null	2026-01-28 20:03:45.185994+00	9abc693e-974d-4649-b816-fac0290441d2	\N	7
8b20dd14-bf7b-485e-9b8d-c3b3d12bf011	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	lobbed	A	\N	\N	\N	null	2026-01-28 20:03:45.894509+00	9abc693e-974d-4649-b816-fac0290441d2	\N	8
c590325c-8634-49ee-a3ae-b14b509f8452	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	goal	A	\N	\N	\N	null	2026-01-28 20:03:48.562088+00	9abc693e-974d-4649-b816-fac0290441d2	\N	10
eb35b86c-f8ee-429b-8b6e-6b91fc267f79	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	goal	A	\N	\N	\N	null	2026-01-28 20:03:48.749937+00	9abc693e-974d-4649-b816-fac0290441d2	\N	11
f46dc8b8-77b0-40df-9db2-1a82e06e94ad	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	goal	A	\N	\N	\N	null	2026-01-28 20:03:48.953882+00	9abc693e-974d-4649-b816-fac0290441d2	\N	11
581f851b-25c7-4ca8-869d-df7a559239dd	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	goal	A	\N	\N	\N	null	2026-01-28 20:03:49.280304+00	9abc693e-974d-4649-b816-fac0290441d2	\N	11
a374623d-f000-452d-aa4e-c3a2da9cf2f6	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	goal	A	\N	\N	\N	null	2026-01-28 20:03:49.425085+00	9abc693e-974d-4649-b816-fac0290441d2	\N	11
81f9d82a-e310-400e-b488-aeea79cfae0c	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	goal	A	\N	\N	\N	null	2026-01-28 20:03:49.566562+00	9abc693e-974d-4649-b816-fac0290441d2	\N	11
ab39d0ac-e7cc-4647-b9bb-5d2f0eed1295	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	goal	A	\N	\N	\N	null	2026-01-28 20:03:49.727747+00	9abc693e-974d-4649-b816-fac0290441d2	\N	12
6afb02f2-c28e-443a-8484-37038664fc04	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	goal	A	\N	\N	\N	null	2026-01-28 20:03:51.171798+00	9abc693e-974d-4649-b816-fac0290441d2	\N	13
ad313b2e-bd97-40fe-b0a7-c1bcb6795db8	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	goal	A	\N	\N	\N	null	2026-01-28 20:03:51.258486+00	9abc693e-974d-4649-b816-fac0290441d2	\N	13
9221e3e6-a04f-4588-8591-723960b86a70	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	goal	A	\N	\N	\N	null	2026-01-28 20:03:51.404966+00	9abc693e-974d-4649-b816-fac0290441d2	\N	13
31c72299-7c69-4a2e-a245-fb9fd9c5732b	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	goal	A	\N	\N	\N	null	2026-01-28 20:03:51.5555+00	9abc693e-974d-4649-b816-fac0290441d2	\N	13
00d6e429-67e7-422d-8d69-ad16b4cbcf62	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	gamellized	A	\N	\N	\N	null	2026-01-28 20:03:52.56532+00	9abc693e-974d-4649-b816-fac0290441d2	\N	14
1ebc3625-2437-4680-b3ac-573bd8d230a6	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	gamellized	A	\N	\N	\N	null	2026-01-28 20:03:52.99708+00	9abc693e-974d-4649-b816-fac0290441d2	\N	15
0b0988f1-8c50-4f34-b51b-f4af59598ff6	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	lobbed	A	\N	\N	\N	null	2026-01-28 20:03:53.561945+00	9abc693e-974d-4649-b816-fac0290441d2	\N	15
2a9c8825-3c06-4bb4-b522-b3b7b2f8ff15	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	goal	A	\N	\N	\N	null	2026-01-28 20:03:54.344524+00	9abc693e-974d-4649-b816-fac0290441d2	\N	16
9a262205-9f46-40f1-8d3c-86a07b5895de	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	goal	A	\N	\N	\N	null	2026-01-28 20:03:54.482247+00	9abc693e-974d-4649-b816-fac0290441d2	\N	16
1691a0b3-ae61-441c-8b59-fba9d8d567e0	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	goal	A	\N	\N	\N	null	2026-01-28 20:03:54.642866+00	9abc693e-974d-4649-b816-fac0290441d2	\N	17
dd6f5445-5ea5-467a-b307-965b5b97129e	1d28b8e0-273e-459b-9522-d8b9ee34f989	goal	B	\N	\N	\N	null	2026-01-28 21:59:31.068341+00	9abc693e-974d-4649-b816-fac0290441d2	\N	0
4b67a9fb-80fc-4a63-9bd8-d15d25fd01ce	1d28b8e0-273e-459b-9522-d8b9ee34f989	goal	B	\N	\N	\N	null	2026-01-28 21:59:31.233776+00	9abc693e-974d-4649-b816-fac0290441d2	\N	0
a4abdc88-9118-47fa-9207-3995c35c31f4	1d28b8e0-273e-459b-9522-d8b9ee34f989	gamellized	A	\N	\N	\N	null	2026-01-28 21:59:32.070194+00	9abc693e-974d-4649-b816-fac0290441d2	\N	1
1bc18b81-827c-4dae-824d-eb95ea1cc9df	1d28b8e0-273e-459b-9522-d8b9ee34f989	lobbed	B	\N	\N	\N	null	2026-01-28 21:59:33.785787+00	9abc693e-974d-4649-b816-fac0290441d2	\N	3
95edd983-f3b1-4eb9-8880-5717531a3c12	1d28b8e0-273e-459b-9522-d8b9ee34f989	goal	A	\N	\N	\N	null	2026-01-28 21:59:35.20392+00	9abc693e-974d-4649-b816-fac0290441d2	\N	4
070e80ec-945a-403c-bdb8-95fd5866d4d1	1d28b8e0-273e-459b-9522-d8b9ee34f989	goal	A	\N	\N	\N	null	2026-01-28 21:59:35.360256+00	9abc693e-974d-4649-b816-fac0290441d2	\N	5
\.


--
-- Data for Name: live_match_session_players; Type: TABLE DATA; Schema: public; Owner: foospulse
--

COPY public.live_match_session_players (id, session_id, player_id, team, "position") FROM stdin;
f5e88ac0-e6eb-4650-b810-f693f0e39d75	3fa25f1c-5577-46ee-8351-a7368e9b96c3	a435c102-0bdc-449e-ad56-727e42975cb7	A	attack
a3d304ed-1351-49d8-9f3c-943f466cd20f	3fa25f1c-5577-46ee-8351-a7368e9b96c3	fc83e69d-2909-4934-9ac2-dc0c91524bdb	B	attack
21caf8ef-e661-4412-bb99-13547458cca0	70d50640-1159-461b-8e35-b22662968ee2	2aebbb9b-7461-4489-a135-6f61c9bf9643	A	attack
13c17deb-5ccb-4b9d-a9c1-68f44422ceb2	70d50640-1159-461b-8e35-b22662968ee2	a435c102-0bdc-449e-ad56-727e42975cb7	B	attack
2f8ea345-9b9b-4c65-9d67-46eb904d9ed3	c8aab6af-2dc0-4c1d-bfd1-8f77332c0c96	2aebbb9b-7461-4489-a135-6f61c9bf9643	A	attack
14e483e5-45e0-4c78-b2e6-72eaba6cd962	c8aab6af-2dc0-4c1d-bfd1-8f77332c0c96	a435c102-0bdc-449e-ad56-727e42975cb7	B	attack
00270cb6-5f2c-4383-864b-052414c55814	32f8cc31-1b5e-4ce8-aa69-6b3bdd75d3c6	fc83e69d-2909-4934-9ac2-dc0c91524bdb	A	attack
21177140-a2df-45b7-8006-a36046b0818f	32f8cc31-1b5e-4ce8-aa69-6b3bdd75d3c6	3aa26a43-1a89-4cd5-8dd3-22dee1537006	A	defense
bd0a47aa-dc2a-48f7-96f5-059c17660d85	32f8cc31-1b5e-4ce8-aa69-6b3bdd75d3c6	2aebbb9b-7461-4489-a135-6f61c9bf9643	B	attack
9f13182f-0f30-42ea-8dbf-1dec39a0b9fa	32f8cc31-1b5e-4ce8-aa69-6b3bdd75d3c6	a435c102-0bdc-449e-ad56-727e42975cb7	B	defense
e565938f-a086-4f1e-b282-a945168123ef	3e94afc7-5535-4542-b11b-506084e099e6	0bca3ab6-6f5f-4ba4-8525-b958523548e0	A	attack
dca33abb-a3ee-41de-a7be-35b3d7e5be83	3e94afc7-5535-4542-b11b-506084e099e6	2aebbb9b-7461-4489-a135-6f61c9bf9643	B	attack
b3feee4e-c518-495c-a1c5-755dd95b4b38	4c987b67-27c6-498d-bae3-25b66d18e4ba	3aa26a43-1a89-4cd5-8dd3-22dee1537006	A	attack
def24133-e64e-4de7-ad07-6fca20752d9e	4c987b67-27c6-498d-bae3-25b66d18e4ba	a435c102-0bdc-449e-ad56-727e42975cb7	B	attack
0e906666-036b-4620-b1bf-22b065cbd612	eb7e1611-7352-48a1-935e-d1ea67df662a	0bca3ab6-6f5f-4ba4-8525-b958523548e0	A	attack
2a93da41-29b0-41d8-b764-4f14f7362da3	eb7e1611-7352-48a1-935e-d1ea67df662a	2aebbb9b-7461-4489-a135-6f61c9bf9643	B	attack
a2f924d4-64e5-4e24-99d4-93560e350f64	c2471429-18ae-4366-93ed-1bc90ffc65f5	a435c102-0bdc-449e-ad56-727e42975cb7	A	attack
c41e08aa-5f4b-4c88-9fb3-bb093ee708c1	c2471429-18ae-4366-93ed-1bc90ffc65f5	057366ea-f970-414f-b1b1-6c419a14d5a3	A	defense
135074d3-ba45-4325-abca-2e1e36f31d98	c2471429-18ae-4366-93ed-1bc90ffc65f5	0bca3ab6-6f5f-4ba4-8525-b958523548e0	B	attack
f78a4507-adca-43cb-bc31-c652ba3a0585	c2471429-18ae-4366-93ed-1bc90ffc65f5	c4e1a678-733e-472a-a617-1731955c67c9	B	defense
659fa258-4551-4f48-a02a-986a66ddbf7d	86b28a3e-94c0-407e-8a3f-f0223fbc09da	fc83e69d-2909-4934-9ac2-dc0c91524bdb	A	attack
542cb439-6f17-4606-8ba2-431a2beec3d1	86b28a3e-94c0-407e-8a3f-f0223fbc09da	a435c102-0bdc-449e-ad56-727e42975cb7	B	attack
2770b7e7-b578-499c-bb28-a50a628b272d	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	3fa970ed-06c8-4856-bd6a-bdcbc8afde04	A	attack
92af871c-24ee-4c70-a25b-2ae3e8a43469	108bbab9-cc7f-4ff0-9b06-9c07e707de4c	40e3f3ae-b802-4671-be6c-1a5e889ac02c	B	attack
6a584016-def3-469e-95b5-481b9889707b	1d28b8e0-273e-459b-9522-d8b9ee34f989	40e3f3ae-b802-4671-be6c-1a5e889ac02c	A	attack
34a401b3-4ec7-497c-be4f-168360f4e2a4	1d28b8e0-273e-459b-9522-d8b9ee34f989	3fa970ed-06c8-4856-bd6a-bdcbc8afde04	B	attack
\.


--
-- Data for Name: live_match_sessions; Type: TABLE DATA; Schema: public; Owner: foospulse
--

COPY public.live_match_sessions (id, league_id, season_id, share_token, scorer_secret, mode, status, team_a_score, team_b_score, created_by_user_id, started_at, ended_at, finalized_match_id, created_at, updated_at) FROM stdin;
70d50640-1159-461b-8e35-b22662968ee2	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	Kd_vIY_bH45UxIoovdN_2A	K7WyrPwHltkn3adUaPNUK2gnWePvI-Qe	1v1	active	5	1	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	2026-01-28 13:21:48.422275+00	\N	\N	2026-01-28 13:21:38.526685+00	2026-01-28 13:28:40.735528+00
86b28a3e-94c0-407e-8a3f-f0223fbc09da	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	SQj5AbH7J8dktlmR_hFcEA	73gGRVtRIP_rBYfw844961RvCEHNsvU-	1v1	completed	3	0	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	2026-01-28 15:00:49.063566+00	2026-01-28 15:00:55.138526+00	659be989-b455-4d2e-8cf5-4da8537f6f28	2026-01-28 15:00:48.156157+00	2026-01-28 15:00:55.138531+00
3fa25f1c-5577-46ee-8351-a7368e9b96c3	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	0hmTP5gOP4xSmDK1NOCw9Q	_U7WOyqXxv817rozPwqBxVUwb_qW9o0u	1v1	active	3	3	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	2026-01-28 12:46:59.34713+00	\N	\N	2026-01-28 12:46:46.823254+00	2026-01-28 12:48:30.955102+00
108bbab9-cc7f-4ff0-9b06-9c07e707de4c	5c900756-8c86-476c-afaf-5115705dccd8	92d9eeac-f264-4b8f-8b3b-990a929af9f3	Gkc9uoNyQF48vnfsTyKoEg	oPGR9eAehVXdxBuwessnw2UrqHEx-WT9	1v1	completed	1	1	9abc693e-974d-4649-b816-fac0290441d2	2026-01-28 20:03:37.475845+00	2026-01-28 20:03:56.747087+00	fb3d1c31-0008-47cf-975c-39eab17361aa	2026-01-28 20:03:33.994185+00	2026-01-28 20:03:56.747091+00
eb7e1611-7352-48a1-935e-d1ea67df662a	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	lQWfvc6xcN4O8R0wJ3IVuA	09HlHMlPw8Q-qPHe7waoafD8jv5-C8nr	1v1	active	0	-3	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	2026-01-28 14:20:55.149602+00	\N	\N	2026-01-28 14:20:55.08982+00	2026-01-28 14:20:55.233472+00
c8aab6af-2dc0-4c1d-bfd1-8f77332c0c96	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	OmqLUc6j08DOvAEOZwCXcA	2l_ovgnO9bFFzoeUuccOOWtp6y9qajJv	1v1	active	9	5	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	2026-01-28 13:49:22.279549+00	\N	\N	2026-01-28 13:49:20.796123+00	2026-01-28 14:17:17.760272+00
c2471429-18ae-4366-93ed-1bc90ffc65f5	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	CW1TkDzoY5G2dvJyB3Tazw	_KEGhzxm93LAz8agzW1kl4JoZ_qwBr1-	2v2	completed	3	1	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	2026-01-28 14:58:48.960496+00	2026-01-28 14:59:04.41801+00	a7a523ad-ab85-447c-9c1b-29ea1d1d66ba	2026-01-28 14:58:46.583614+00	2026-01-28 14:59:04.418015+00
3e94afc7-5535-4542-b11b-506084e099e6	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	7rrqsmM5zTnexOI2ZgyeDg	E3rdjUHTMLms-2NVLyt1WaIl3BH80J2I	1v1	active	1	0	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	2026-01-28 14:19:34.655553+00	\N	\N	2026-01-28 14:19:07.109502+00	2026-01-28 14:19:47.8275+00
4c987b67-27c6-498d-bae3-25b66d18e4ba	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	PXW03xJ4UZza-ZKFmkJewA	d2MuoxLBonHPcmXNNuRipq4bUNmuV_FB	1v1	completed	5	4	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	2026-01-28 14:20:38.244404+00	2026-01-28 14:27:47.833484+00	d8c9a600-2655-4faf-959c-4bbd23ebb2b4	2026-01-28 14:20:36.962721+00	2026-01-28 14:27:47.833489+00
1d28b8e0-273e-459b-9522-d8b9ee34f989	5c900756-8c86-476c-afaf-5115705dccd8	92d9eeac-f264-4b8f-8b3b-990a929af9f3	oV1yfRrDcNVeBeU6x1ljeQ	UGMlzZl8mbArBmWLl9rBZlDGH3exxXJX	1v1	completed	1	-1	9abc693e-974d-4649-b816-fac0290441d2	2026-01-28 21:59:30.269237+00	2026-01-28 21:59:37.087981+00	bdee5d6b-0bd1-45bc-bc9c-0d89613f9813	2026-01-28 21:59:28.098314+00	2026-01-28 21:59:37.087988+00
32f8cc31-1b5e-4ce8-aa69-6b3bdd75d3c6	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	-4_dKFGkVM1Pwz-lPMjzhQ	tYFHpoRoaXotYz7KtpLAcPgW8mhlkofI	2v2	active	-3	2	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	2026-01-28 14:18:33.40512+00	\N	\N	2026-01-28 14:18:29.240211+00	2026-01-28 14:20:04.430262+00
\.


--
-- Data for Name: match_events; Type: TABLE DATA; Schema: public; Owner: foospulse
--

COPY public.match_events (id, match_id, event_type, against_player_id, by_player_id, count) FROM stdin;
34f980af-8b74-4e5e-aa5e-b53091358ebf	4faa5d58-b689-4b3a-b6f8-43a8e8d54ca8	gamelle	0bca3ab6-6f5f-4ba4-8525-b958523548e0	057366ea-f970-414f-b1b1-6c419a14d5a3	1
b02a5187-9923-45c5-9096-4e46c83b172e	13220717-f9b5-4725-bd95-d42023fed2a1	gamelle	0bca3ab6-6f5f-4ba4-8525-b958523548e0	fc83e69d-2909-4934-9ac2-dc0c91524bdb	1
f3c4e6fc-a342-4fc1-8206-25cac29755da	3b4eed08-863d-44b6-970b-77dca5fefc0a	gamelle	3aa26a43-1a89-4cd5-8dd3-22dee1537006	057366ea-f970-414f-b1b1-6c419a14d5a3	3
ba4066d9-4f70-4173-b5d5-3587fcaf6774	915ad417-8b33-446d-8220-b29f9d6e169c	gamelle	2aebbb9b-7461-4489-a135-6f61c9bf9643	fc83e69d-2909-4934-9ac2-dc0c91524bdb	3
\.


--
-- Data for Name: match_players; Type: TABLE DATA; Schema: public; Owner: foospulse
--

COPY public.match_players (id, match_id, player_id, team, "position", is_captain) FROM stdin;
19b3ee92-ed79-4f90-a998-58b966b98f6c	4faa5d58-b689-4b3a-b6f8-43a8e8d54ca8	0bca3ab6-6f5f-4ba4-8525-b958523548e0	A	attack	t
db20ee08-53e4-491f-939f-912b63519e5e	4faa5d58-b689-4b3a-b6f8-43a8e8d54ca8	057366ea-f970-414f-b1b1-6c419a14d5a3	A	defense	f
192f2a09-7e77-41eb-a880-ffc778e88f91	4faa5d58-b689-4b3a-b6f8-43a8e8d54ca8	2aebbb9b-7461-4489-a135-6f61c9bf9643	B	attack	t
539c9038-0ccc-4c76-8c4c-451a6bbede29	4faa5d58-b689-4b3a-b6f8-43a8e8d54ca8	c4e1a678-733e-472a-a617-1731955c67c9	B	defense	f
20dd517d-3d5f-4d7e-b948-5a993f8d891f	3d733beb-2ed4-452a-8c3d-32bca592228d	3aa26a43-1a89-4cd5-8dd3-22dee1537006	A	attack	t
3aa549d4-7a3a-43cb-8aa8-1983fcc745f5	3d733beb-2ed4-452a-8c3d-32bca592228d	2aebbb9b-7461-4489-a135-6f61c9bf9643	A	defense	f
ad2559b2-ac44-4c6c-8dd4-361c4d42a488	3d733beb-2ed4-452a-8c3d-32bca592228d	057366ea-f970-414f-b1b1-6c419a14d5a3	B	attack	t
1cd16826-ae8d-4aad-a361-5bae51d6d7f6	3d733beb-2ed4-452a-8c3d-32bca592228d	0bca3ab6-6f5f-4ba4-8525-b958523548e0	B	defense	f
fdb96f7b-55d3-4f1c-8d47-0c5452979f41	c19f1209-d7da-40f3-96aa-200520c8b891	057366ea-f970-414f-b1b1-6c419a14d5a3	A	attack	t
31ad468d-498d-4d76-a63d-95e3ab12feb5	c19f1209-d7da-40f3-96aa-200520c8b891	2aebbb9b-7461-4489-a135-6f61c9bf9643	B	defense	t
a831bf41-b9ff-4e5f-a6bb-3fcc0f94e3d5	215dfbee-1cbd-40c4-951a-4383606a1892	3aa26a43-1a89-4cd5-8dd3-22dee1537006	A	attack	t
3b222d72-1ca2-407d-83d5-cea5efe401f1	215dfbee-1cbd-40c4-951a-4383606a1892	2aebbb9b-7461-4489-a135-6f61c9bf9643	B	defense	t
5c540793-653f-4ccd-b910-86292f3f98a5	afe9cd4a-0833-4e31-8729-b7b177a28a29	c4e1a678-733e-472a-a617-1731955c67c9	A	attack	t
ca388bd5-7f2b-472d-a486-16132c4eb36b	afe9cd4a-0833-4e31-8729-b7b177a28a29	0bca3ab6-6f5f-4ba4-8525-b958523548e0	A	defense	f
2283edbe-426e-4c97-ae04-f34981f6998e	afe9cd4a-0833-4e31-8729-b7b177a28a29	2aebbb9b-7461-4489-a135-6f61c9bf9643	B	attack	t
61f310a6-bf4b-49d7-8c9c-2f3be25712c4	afe9cd4a-0833-4e31-8729-b7b177a28a29	3aa26a43-1a89-4cd5-8dd3-22dee1537006	B	defense	f
28278437-4e5a-4bd5-9e89-7bd20b4709e4	6fb1f751-37a3-40bd-8cab-a2f03431caeb	fc83e69d-2909-4934-9ac2-dc0c91524bdb	A	attack	t
7e7c7c4e-8552-4d34-b366-b627932fa8c7	6fb1f751-37a3-40bd-8cab-a2f03431caeb	c4e1a678-733e-472a-a617-1731955c67c9	B	defense	t
d4b87e36-af4b-445f-b816-1572625750ee	13220717-f9b5-4725-bd95-d42023fed2a1	3aa26a43-1a89-4cd5-8dd3-22dee1537006	A	attack	t
988de0c4-2d2a-42b7-835f-ac536cc7232e	13220717-f9b5-4725-bd95-d42023fed2a1	0bca3ab6-6f5f-4ba4-8525-b958523548e0	A	defense	f
89b35afd-33d5-41f3-a393-666dd6b5a3ad	13220717-f9b5-4725-bd95-d42023fed2a1	fc83e69d-2909-4934-9ac2-dc0c91524bdb	B	attack	t
7601f8a2-282c-4add-ba65-8bef4c49e9cf	13220717-f9b5-4725-bd95-d42023fed2a1	c4e1a678-733e-472a-a617-1731955c67c9	B	defense	f
64b82593-0baf-44fc-970d-9a11dea41dfa	d2325a5c-0468-44fe-acf9-aa9771e04069	c4e1a678-733e-472a-a617-1731955c67c9	A	attack	t
8d3e625c-ca02-4e3d-829d-a31b038950ca	d2325a5c-0468-44fe-acf9-aa9771e04069	fc83e69d-2909-4934-9ac2-dc0c91524bdb	A	defense	f
c7220871-4f79-4d87-90ed-a9a0012da84b	d2325a5c-0468-44fe-acf9-aa9771e04069	0bca3ab6-6f5f-4ba4-8525-b958523548e0	B	attack	t
9ccffe81-f831-4b67-b4b5-43d266803a2f	d2325a5c-0468-44fe-acf9-aa9771e04069	3aa26a43-1a89-4cd5-8dd3-22dee1537006	B	defense	f
f7c9fe6d-2070-4e8a-8a5f-c9c716bbfad3	3b4eed08-863d-44b6-970b-77dca5fefc0a	2aebbb9b-7461-4489-a135-6f61c9bf9643	A	attack	t
929bb1e4-3038-42bb-91c2-ba746d8128dd	3b4eed08-863d-44b6-970b-77dca5fefc0a	057366ea-f970-414f-b1b1-6c419a14d5a3	A	defense	f
a0645868-b053-4597-9af7-3997973dcf40	3b4eed08-863d-44b6-970b-77dca5fefc0a	3aa26a43-1a89-4cd5-8dd3-22dee1537006	B	attack	t
a81714f0-b4b1-4da4-92b1-63bee5f16fae	3b4eed08-863d-44b6-970b-77dca5fefc0a	fc83e69d-2909-4934-9ac2-dc0c91524bdb	B	defense	f
ee832781-efac-44f0-8a89-68dcfc895789	1db72d1f-03d3-4739-9f59-2e6f4254d267	c4e1a678-733e-472a-a617-1731955c67c9	A	attack	t
2a63cfee-6ae2-446e-91c8-7ef4fe872e81	1db72d1f-03d3-4739-9f59-2e6f4254d267	057366ea-f970-414f-b1b1-6c419a14d5a3	A	defense	f
b2619cec-bdff-4a2a-bb69-2ef5c71d3656	1db72d1f-03d3-4739-9f59-2e6f4254d267	0bca3ab6-6f5f-4ba4-8525-b958523548e0	B	attack	t
8006303a-5125-42dd-8d2b-971ab0529086	1db72d1f-03d3-4739-9f59-2e6f4254d267	fc83e69d-2909-4934-9ac2-dc0c91524bdb	B	defense	f
c996b469-1aa6-41fa-9987-a0226a3909ad	ff0f1f4d-0af4-46b2-88e0-a8a792d72a83	0bca3ab6-6f5f-4ba4-8525-b958523548e0	A	attack	t
ee24bac6-a76a-43ff-97b8-d9179a6dc3b2	ff0f1f4d-0af4-46b2-88e0-a8a792d72a83	c4e1a678-733e-472a-a617-1731955c67c9	B	defense	t
528d3d25-4915-4b03-bda5-0c9740fb0bdf	18c65d8e-8bca-498c-924d-16f3993f0ee9	3aa26a43-1a89-4cd5-8dd3-22dee1537006	A	attack	t
ef3b2209-9aa7-42a3-a34d-6565f94a2dcd	18c65d8e-8bca-498c-924d-16f3993f0ee9	fc83e69d-2909-4934-9ac2-dc0c91524bdb	A	defense	f
c2f9f5d4-be46-48c8-8aed-c0552a8254a0	18c65d8e-8bca-498c-924d-16f3993f0ee9	057366ea-f970-414f-b1b1-6c419a14d5a3	B	attack	t
f5bc6923-40b1-417e-8527-420be8c7e136	18c65d8e-8bca-498c-924d-16f3993f0ee9	c4e1a678-733e-472a-a617-1731955c67c9	B	defense	f
4545b72a-fbce-4c8e-87ab-bf35058e1f59	e7f86607-c171-4f33-9a6b-2cb81af82683	2aebbb9b-7461-4489-a135-6f61c9bf9643	A	attack	t
03fd45fe-33e1-4021-94fa-64f6ea0f9363	e7f86607-c171-4f33-9a6b-2cb81af82683	c4e1a678-733e-472a-a617-1731955c67c9	B	defense	t
9eecbdf5-cafe-4504-b02f-cf7d9c1d0b9b	1ba8ae2f-d583-47a1-bcf4-28c0ce510ab0	057366ea-f970-414f-b1b1-6c419a14d5a3	A	attack	t
f076df6e-fc56-4948-91bf-6a753ab75124	1ba8ae2f-d583-47a1-bcf4-28c0ce510ab0	3aa26a43-1a89-4cd5-8dd3-22dee1537006	B	defense	t
c60a3b52-c1b4-4ea2-8a68-d95cca9f93fc	aaf1c95d-ec46-4ed7-a1fe-93d1d57049b9	2aebbb9b-7461-4489-a135-6f61c9bf9643	A	attack	t
a0fbb446-80a8-4421-9bf8-d98c689d7fbd	aaf1c95d-ec46-4ed7-a1fe-93d1d57049b9	057366ea-f970-414f-b1b1-6c419a14d5a3	B	defense	t
e96b435c-5d0a-4190-8da1-680a3cba4dd6	915ad417-8b33-446d-8220-b29f9d6e169c	2aebbb9b-7461-4489-a135-6f61c9bf9643	A	attack	t
abef982b-6236-44b0-828e-7c01595b0bf1	915ad417-8b33-446d-8220-b29f9d6e169c	fc83e69d-2909-4934-9ac2-dc0c91524bdb	B	defense	t
d1ad8781-597e-43ac-a051-9186ebd03baf	bdbab94b-d08d-4d49-ba60-d2b086b0703a	0bca3ab6-6f5f-4ba4-8525-b958523548e0	A	attack	t
904520ea-01b9-461f-b776-0959507d7e91	bdbab94b-d08d-4d49-ba60-d2b086b0703a	2aebbb9b-7461-4489-a135-6f61c9bf9643	B	defense	t
d058db89-0ff5-4f43-939a-1f9a480032c0	3a7af98c-9cae-4e5b-bef9-9a20c6febb41	fc83e69d-2909-4934-9ac2-dc0c91524bdb	A	attack	t
4eff4409-3553-438f-b76e-409756c711dd	3a7af98c-9cae-4e5b-bef9-9a20c6febb41	c4e1a678-733e-472a-a617-1731955c67c9	A	defense	f
c0fba4e4-7e92-4fef-93a3-8aea806cfae0	3a7af98c-9cae-4e5b-bef9-9a20c6febb41	2aebbb9b-7461-4489-a135-6f61c9bf9643	B	attack	t
feeac09c-1260-46c2-ada4-e75163533d38	3a7af98c-9cae-4e5b-bef9-9a20c6febb41	3aa26a43-1a89-4cd5-8dd3-22dee1537006	B	defense	f
4ec8ea02-132a-4977-860f-7907700aebf2	50a5cfd1-9383-408a-baac-7be05a273f91	c4e1a678-733e-472a-a617-1731955c67c9	A	attack	t
e3824a9d-5eb1-4092-b7ce-c58d968b7423	50a5cfd1-9383-408a-baac-7be05a273f91	0bca3ab6-6f5f-4ba4-8525-b958523548e0	B	defense	t
5534b0b8-112b-4781-9cb8-9511ef3578ef	b2156cfd-d606-4ca8-a53b-123c19138158	2aebbb9b-7461-4489-a135-6f61c9bf9643	A	attack	t
df3bd4ca-85af-486d-8652-88125d0dff2d	b2156cfd-d606-4ca8-a53b-123c19138158	057366ea-f970-414f-b1b1-6c419a14d5a3	A	defense	f
65698d70-27e0-44a0-bf66-bde362f6197a	b2156cfd-d606-4ca8-a53b-123c19138158	c4e1a678-733e-472a-a617-1731955c67c9	B	attack	t
83d1d9ca-6910-4e4f-bb16-f2b2c8b6b338	b2156cfd-d606-4ca8-a53b-123c19138158	fc83e69d-2909-4934-9ac2-dc0c91524bdb	B	defense	f
cd8988e3-accf-4f54-a7af-20beaf88cb3e	167e8b8e-9f20-44c5-8c21-7c91ff0d34bf	0bca3ab6-6f5f-4ba4-8525-b958523548e0	A	attack	f
48c1f3ee-d399-45bf-bec3-9bc2f251a221	167e8b8e-9f20-44c5-8c21-7c91ff0d34bf	3aa26a43-1a89-4cd5-8dd3-22dee1537006	A	defense	f
4b5312ce-e9e9-404f-ab83-0442b26e2e09	167e8b8e-9f20-44c5-8c21-7c91ff0d34bf	2aebbb9b-7461-4489-a135-6f61c9bf9643	B	attack	f
c011b14b-0625-493d-97dc-9d863148ecc1	167e8b8e-9f20-44c5-8c21-7c91ff0d34bf	fc83e69d-2909-4934-9ac2-dc0c91524bdb	B	defense	f
60ba84c3-7a22-4555-9656-a1a35ff239f1	33fd0705-fc4b-4370-98a4-8d50e71160e9	0bca3ab6-6f5f-4ba4-8525-b958523548e0	A	attack	f
cbba9e2e-09be-46a5-8f37-d84652671633	33fd0705-fc4b-4370-98a4-8d50e71160e9	2aebbb9b-7461-4489-a135-6f61c9bf9643	B	defense	f
a472b8a0-ad11-4180-a426-dee50ad7ec94	d8c9a600-2655-4faf-959c-4bbd23ebb2b4	3aa26a43-1a89-4cd5-8dd3-22dee1537006	A	attack	f
3219c3fb-e8a2-4dc3-bcdd-3c62a247a091	d8c9a600-2655-4faf-959c-4bbd23ebb2b4	a435c102-0bdc-449e-ad56-727e42975cb7	B	attack	f
2ab55950-f369-4e55-b9c9-1f533d7d2d35	a7a523ad-ab85-447c-9c1b-29ea1d1d66ba	a435c102-0bdc-449e-ad56-727e42975cb7	A	attack	f
eb4ebb4c-925a-4349-9945-f368f6e7b3e0	a7a523ad-ab85-447c-9c1b-29ea1d1d66ba	057366ea-f970-414f-b1b1-6c419a14d5a3	A	defense	f
efb58e26-f3bf-4ff2-9b61-334873495529	a7a523ad-ab85-447c-9c1b-29ea1d1d66ba	0bca3ab6-6f5f-4ba4-8525-b958523548e0	B	attack	f
7359a062-893e-4ff6-9827-9da0779ccfff	a7a523ad-ab85-447c-9c1b-29ea1d1d66ba	c4e1a678-733e-472a-a617-1731955c67c9	B	defense	f
feefcdf0-e5d6-418c-b31d-781689f6e550	659be989-b455-4d2e-8cf5-4da8537f6f28	fc83e69d-2909-4934-9ac2-dc0c91524bdb	A	attack	f
7550233f-6283-41dc-9f02-38660c7602e3	659be989-b455-4d2e-8cf5-4da8537f6f28	a435c102-0bdc-449e-ad56-727e42975cb7	B	attack	f
0b6550fc-d159-486a-8578-dedd2a4eeec6	fb3d1c31-0008-47cf-975c-39eab17361aa	3fa970ed-06c8-4856-bd6a-bdcbc8afde04	A	attack	f
f559788f-b510-45a2-96ed-fbfe0674849c	fb3d1c31-0008-47cf-975c-39eab17361aa	40e3f3ae-b802-4671-be6c-1a5e889ac02c	B	attack	f
2960bace-478e-412c-ab84-cf0b947af748	bdee5d6b-0bd1-45bc-bc9c-0d89613f9813	40e3f3ae-b802-4671-be6c-1a5e889ac02c	A	attack	f
3351781d-2606-46c8-999a-9e5cf5f7fb18	bdee5d6b-0bd1-45bc-bc9c-0d89613f9813	3fa970ed-06c8-4856-bd6a-bdcbc8afde04	B	attack	f
fd1ce062-9c58-4143-b121-9fdf5cbf604b	4a904595-d7e5-4cfc-bf97-4e06471a7799	3fa970ed-06c8-4856-bd6a-bdcbc8afde04	A	attack	f
a11365b0-b3aa-40ae-a759-55682d5ffb91	4a904595-d7e5-4cfc-bf97-4e06471a7799	40e3f3ae-b802-4671-be6c-1a5e889ac02c	B	defense	f
\.


--
-- Data for Name: matches; Type: TABLE DATA; Schema: public; Owner: foospulse
--

COPY public.matches (id, league_id, season_id, mode, team_a_score, team_b_score, played_at, created_by_player_id, status, void_reason, created_at) FROM stdin;
4faa5d58-b689-4b3a-b6f8-43a8e8d54ca8	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	2v2	9	10	2026-01-16 15:55:03.447044+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.50689+00
3d733beb-2ed4-452a-8c3d-32bca592228d	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	2v2	10	3	2026-01-16 11:55:03.542223+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.543173+00
c19f1209-d7da-40f3-96aa-200520c8b891	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	1v1	10	2	2026-01-15 06:55:03.600044+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.600914+00
215dfbee-1cbd-40c4-951a-4383606a1892	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	1v1	10	0	2026-01-13 09:55:03.608136+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.608598+00
afe9cd4a-0833-4e31-8729-b7b177a28a29	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	2v2	10	0	2026-01-17 15:55:03.612697+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.614022+00
6fb1f751-37a3-40bd-8cab-a2f03431caeb	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	1v1	3	10	2026-01-07 03:55:03.617308+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.617917+00
13220717-f9b5-4725-bd95-d42023fed2a1	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	2v2	10	2	2026-01-04 04:55:03.622496+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.622875+00
d2325a5c-0468-44fe-acf9-aa9771e04069	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	2v2	10	0	2026-01-24 14:55:03.624512+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.625155+00
3b4eed08-863d-44b6-970b-77dca5fefc0a	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	2v2	10	4	2025-12-31 11:55:03.638794+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.639368+00
1db72d1f-03d3-4739-9f59-2e6f4254d267	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	2v2	10	9	2026-01-06 03:55:03.641605+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.641862+00
ff0f1f4d-0af4-46b2-88e0-a8a792d72a83	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	1v1	6	10	2026-01-04 13:55:03.644536+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.645768+00
18c65d8e-8bca-498c-924d-16f3993f0ee9	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	2v2	10	3	2026-01-17 05:55:03.648142+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.648863+00
e7f86607-c171-4f33-9a6b-2cb81af82683	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	1v1	0	10	2026-01-19 09:55:03.659071+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.65964+00
1ba8ae2f-d583-47a1-bcf4-28c0ce510ab0	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	1v1	9	10	2026-01-27 07:55:03.661969+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.662332+00
aaf1c95d-ec46-4ed7-a1fe-93d1d57049b9	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	1v1	3	10	2026-01-16 10:55:03.664293+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.664554+00
915ad417-8b33-446d-8220-b29f9d6e169c	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	1v1	10	2	2026-01-06 06:55:03.666675+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.666916+00
bdbab94b-d08d-4d49-ba60-d2b086b0703a	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	1v1	10	4	2026-01-16 03:55:03.669071+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.670198+00
3a7af98c-9cae-4e5b-bef9-9a20c6febb41	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	2v2	10	0	2025-12-28 03:55:03.675995+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.676345+00
50a5cfd1-9383-408a-baac-7be05a273f91	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	1v1	10	2	2026-01-20 11:55:03.678521+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.678772+00
b2156cfd-d606-4ca8-a53b-123c19138158	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	2v2	9	10	2026-01-13 05:55:03.680569+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 15:55:03.68128+00
167e8b8e-9f20-44c5-8c21-7c91ff0d34bf	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	2v2	10	3	2026-01-27 17:21:23.545271+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 17:21:23.562462+00
33fd0705-fc4b-4370-98a4-8d50e71160e9	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	1v1	10	5	2026-01-27 17:46:56.17649+00	0bca3ab6-6f5f-4ba4-8525-b958523548e0	valid	\N	2026-01-27 17:46:56.178883+00
d8c9a600-2655-4faf-959c-4bbd23ebb2b4	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	1v1	5	4	2026-01-28 14:20:38.244404+00	\N	valid	\N	2026-01-28 14:27:47.813441+00
a7a523ad-ab85-447c-9c1b-29ea1d1d66ba	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	2v2	3	1	2026-01-28 14:58:48.960496+00	\N	valid	\N	2026-01-28 14:59:04.399286+00
659be989-b455-4d2e-8cf5-4da8537f6f28	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	1v1	3	0	2026-01-28 15:00:49.063566+00	\N	valid	\N	2026-01-28 15:00:55.107207+00
fb3d1c31-0008-47cf-975c-39eab17361aa	5c900756-8c86-476c-afaf-5115705dccd8	92d9eeac-f264-4b8f-8b3b-990a929af9f3	1v1	1	1	2026-01-28 20:03:37.475845+00	\N	valid	\N	2026-01-28 20:03:56.741537+00
bdee5d6b-0bd1-45bc-bc9c-0d89613f9813	5c900756-8c86-476c-afaf-5115705dccd8	92d9eeac-f264-4b8f-8b3b-990a929af9f3	1v1	1	-1	2026-01-28 21:59:30.269237+00	\N	valid	\N	2026-01-28 21:59:37.07837+00
4a904595-d7e5-4cfc-bf97-4e06471a7799	5c900756-8c86-476c-afaf-5115705dccd8	92d9eeac-f264-4b8f-8b3b-990a929af9f3	1v1	5	4	2026-01-28 22:13:08.032051+00	3fa970ed-06c8-4856-bd6a-bdcbc8afde04	valid	\N	2026-01-28 22:13:08.044565+00
\.


--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: foospulse
--

COPY public.players (id, league_id, user_id, nickname, avatar_url, is_guest, created_at, updated_at) FROM stdin;
0bca3ab6-6f5f-4ba4-8525-b958523548e0	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	Alice	\N	f	2026-01-27 15:55:03.430535+00	2026-01-27 15:55:03.43054+00
2aebbb9b-7461-4489-a135-6f61c9bf9643	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	\N	Bob	\N	t	2026-01-27 15:55:03.43055+00	2026-01-27 15:55:03.430551+00
fc83e69d-2909-4934-9ac2-dc0c91524bdb	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	\N	Charlie	\N	t	2026-01-27 15:55:03.430555+00	2026-01-27 15:55:03.430556+00
3aa26a43-1a89-4cd5-8dd3-22dee1537006	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	\N	Diana	\N	t	2026-01-27 15:55:03.430559+00	2026-01-27 15:55:03.43056+00
057366ea-f970-414f-b1b1-6c419a14d5a3	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	\N	Eve	\N	t	2026-01-27 15:55:03.430564+00	2026-01-27 15:55:03.430565+00
c4e1a678-733e-472a-a617-1731955c67c9	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	\N	Frank	\N	t	2026-01-27 15:55:03.430568+00	2026-01-27 15:55:03.430569+00
a435c102-0bdc-449e-ad56-727e42975cb7	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	\N	Emma	\N	t	2026-01-27 17:49:22.697379+00	2026-01-27 17:49:22.697383+00
3fa970ed-06c8-4856-bd6a-bdcbc8afde04	5c900756-8c86-476c-afaf-5115705dccd8	9abc693e-974d-4649-b816-fac0290441d2	Florian	\N	f	2026-01-28 19:37:59.97631+00	2026-01-28 19:37:59.976311+00
40e3f3ae-b802-4671-be6c-1a5e889ac02c	5c900756-8c86-476c-afaf-5115705dccd8	\N	Test	\N	t	2026-01-28 20:03:25.073329+00	2026-01-28 20:03:25.073332+00
\.


--
-- Data for Name: rating_snapshots; Type: TABLE DATA; Schema: public; Owner: foospulse
--

COPY public.rating_snapshots (id, league_id, season_id, player_id, mode, rating, as_of_match_id, computed_at) FROM stdin;
db3fb3a2-c45f-44c3-9c3e-572bab0ee09a	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	a435c102-0bdc-449e-ad56-727e42975cb7	2v2	1216	a7a523ad-ab85-447c-9c1b-29ea1d1d66ba	2026-01-28 14:59:04.892445+00
178d6b4f-3f03-432e-9ae6-368988e29cdc	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	057366ea-f970-414f-b1b1-6c419a14d5a3	2v2	1216	a7a523ad-ab85-447c-9c1b-29ea1d1d66ba	2026-01-28 14:59:04.895864+00
a5783aa1-e33f-498f-8e2a-cbb2b382214a	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	0bca3ab6-6f5f-4ba4-8525-b958523548e0	2v2	1184	a7a523ad-ab85-447c-9c1b-29ea1d1d66ba	2026-01-28 14:59:04.895901+00
037949d1-7058-4fe9-83bb-ac169e341d35	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	c4e1a678-733e-472a-a617-1731955c67c9	2v2	1184	a7a523ad-ab85-447c-9c1b-29ea1d1d66ba	2026-01-28 14:59:04.895918+00
791985fb-447c-45ef-b2c9-a4ab56569125	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	fc83e69d-2909-4934-9ac2-dc0c91524bdb	1v1	1216	659be989-b455-4d2e-8cf5-4da8537f6f28	2026-01-28 15:00:55.2048+00
ee427af8-6967-4b8b-bf02-115be2ab6ad9	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	a435c102-0bdc-449e-ad56-727e42975cb7	1v1	1184	659be989-b455-4d2e-8cf5-4da8537f6f28	2026-01-28 15:00:55.206461+00
2f169aef-6a62-4540-b901-6faff80c531e	5c900756-8c86-476c-afaf-5115705dccd8	92d9eeac-f264-4b8f-8b3b-990a929af9f3	3fa970ed-06c8-4856-bd6a-bdcbc8afde04	1v1	1184	fb3d1c31-0008-47cf-975c-39eab17361aa	2026-01-28 20:03:57.337765+00
3ae29b8e-8db8-42fa-832e-4506d86d31c0	5c900756-8c86-476c-afaf-5115705dccd8	92d9eeac-f264-4b8f-8b3b-990a929af9f3	40e3f3ae-b802-4671-be6c-1a5e889ac02c	1v1	1216	fb3d1c31-0008-47cf-975c-39eab17361aa	2026-01-28 20:03:57.358984+00
0b4c544c-0ee3-474e-9fe7-2bb839992f90	5c900756-8c86-476c-afaf-5115705dccd8	92d9eeac-f264-4b8f-8b3b-990a929af9f3	40e3f3ae-b802-4671-be6c-1a5e889ac02c	1v1	1231	bdee5d6b-0bd1-45bc-bc9c-0d89613f9813	2026-01-28 21:59:37.845988+00
eab0e370-2c3e-4880-8b96-9d24690541ba	5c900756-8c86-476c-afaf-5115705dccd8	92d9eeac-f264-4b8f-8b3b-990a929af9f3	3fa970ed-06c8-4856-bd6a-bdcbc8afde04	1v1	1169	bdee5d6b-0bd1-45bc-bc9c-0d89613f9813	2026-01-28 21:59:37.847416+00
d197cd6d-d254-4f24-9c14-c070ba5669bf	5c900756-8c86-476c-afaf-5115705dccd8	92d9eeac-f264-4b8f-8b3b-990a929af9f3	3fa970ed-06c8-4856-bd6a-bdcbc8afde04	1v1	1188	4a904595-d7e5-4cfc-bf97-4e06471a7799	2026-01-28 22:13:08.3258+00
f83e376d-1005-45af-81ce-dbb3fcf3b170	5c900756-8c86-476c-afaf-5115705dccd8	92d9eeac-f264-4b8f-8b3b-990a929af9f3	40e3f3ae-b802-4671-be6c-1a5e889ac02c	1v1	1212	4a904595-d7e5-4cfc-bf97-4e06471a7799	2026-01-28 22:13:08.332972+00
\.


--
-- Data for Name: seasons; Type: TABLE DATA; Schema: public; Owner: foospulse
--

COPY public.seasons (id, league_id, name, status, starts_at, ends_at, created_at) FROM stdin;
e3d617ad-e920-419f-a3e5-6e0b4de453d6	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	Season 1	active	2025-12-28	\N	2026-01-27 15:55:03.38778+00
92d9eeac-f264-4b8f-8b3b-990a929af9f3	5c900756-8c86-476c-afaf-5115705dccd8	Season 1	active	2026-01-28	\N	2026-01-28 19:37:59.972339+00
\.


--
-- Data for Name: stats_snapshots; Type: TABLE DATA; Schema: public; Owner: foospulse
--

COPY public.stats_snapshots (id, league_id, season_id, snapshot_type, version, data_json, computed_at, source_hash) FROM stdin;
b5e8a19b-82ab-408c-a399-6745907aeb55	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	leaderboards	v1	{"elo": {"name": "Elo Rating", "entries": [{"rank": 1, "value": 1216, "nickname": "Charlie", "n_matches": 11, "player_id": "fc83e69d-2909-4934-9ac2-dc0c91524bdb"}, {"rank": 2, "value": 1216, "nickname": "Eve", "n_matches": 10, "player_id": "057366ea-f970-414f-b1b1-6c419a14d5a3"}, {"rank": 3, "value": 1200, "nickname": "Diana", "n_matches": 11, "player_id": "3aa26a43-1a89-4cd5-8dd3-22dee1537006"}, {"rank": 4, "value": 1200, "nickname": "Bob", "n_matches": 14, "player_id": "2aebbb9b-7461-4489-a135-6f61c9bf9643"}, {"rank": 5, "value": 1184, "nickname": "Frank", "n_matches": 13, "player_id": "c4e1a678-733e-472a-a617-1731955c67c9"}, {"rank": 6, "value": 1184, "nickname": "Emma", "n_matches": 3, "player_id": "a435c102-0bdc-449e-ad56-727e42975cb7"}, {"rank": 7, "value": 1184, "nickname": "Alice", "n_matches": 12, "player_id": "0bca3ab6-6f5f-4ba4-8525-b958523548e0"}]}, "win_rate": {"name": "Win Rate", "entries": [{"rank": 1, "value": 0.769, "nickname": "Frank", "n_matches": 13, "player_id": "c4e1a678-733e-472a-a617-1731955c67c9"}, {"rank": 2, "value": 0.636, "nickname": "Diana", "n_matches": 11, "player_id": "3aa26a43-1a89-4cd5-8dd3-22dee1537006"}, {"rank": 3, "value": 0.5, "nickname": "Eve", "n_matches": 10, "player_id": "057366ea-f970-414f-b1b1-6c419a14d5a3"}, {"rank": 4, "value": 0.455, "nickname": "Charlie", "n_matches": 11, "player_id": "fc83e69d-2909-4934-9ac2-dc0c91524bdb"}, {"rank": 5, "value": 0.417, "nickname": "Alice", "n_matches": 12, "player_id": "0bca3ab6-6f5f-4ba4-8525-b958523548e0"}, {"rank": 6, "value": 0.333, "nickname": "Emma", "n_matches": 3, "player_id": "a435c102-0bdc-449e-ad56-727e42975cb7"}, {"rank": 7, "value": 0.286, "nickname": "Bob", "n_matches": 14, "player_id": "2aebbb9b-7461-4489-a135-6f61c9bf9643"}]}, "current_streak": {"name": "Current Streak", "entries": [{"rank": 1, "value": 7, "nickname": "Diana", "n_matches": 11, "player_id": "3aa26a43-1a89-4cd5-8dd3-22dee1537006"}, {"rank": 2, "value": 5, "nickname": "Charlie", "n_matches": 11, "player_id": "fc83e69d-2909-4934-9ac2-dc0c91524bdb"}, {"rank": 3, "value": 5, "nickname": "Eve", "n_matches": 10, "player_id": "057366ea-f970-414f-b1b1-6c419a14d5a3"}, {"rank": 4, "value": -2, "nickname": "Emma", "n_matches": 3, "player_id": "a435c102-0bdc-449e-ad56-727e42975cb7"}, {"rank": 5, "value": -3, "nickname": "Frank", "n_matches": 13, "player_id": "c4e1a678-733e-472a-a617-1731955c67c9"}, {"rank": 6, "value": -7, "nickname": "Alice", "n_matches": 12, "player_id": "0bca3ab6-6f5f-4ba4-8525-b958523548e0"}, {"rank": 7, "value": -10, "nickname": "Bob", "n_matches": 14, "player_id": "2aebbb9b-7461-4489-a135-6f61c9bf9643"}]}, "attack_win_rate": {"name": "Attack Win Rate", "entries": [{"rank": 1, "value": 1.0, "nickname": "Frank", "n_matches": 13, "player_id": "c4e1a678-733e-472a-a617-1731955c67c9"}, {"rank": 2, "value": 0.833, "nickname": "Diana", "n_matches": 11, "player_id": "3aa26a43-1a89-4cd5-8dd3-22dee1537006"}, {"rank": 3, "value": 0.5, "nickname": "Charlie", "n_matches": 11, "player_id": "fc83e69d-2909-4934-9ac2-dc0c91524bdb"}, {"rank": 4, "value": 0.375, "nickname": "Alice", "n_matches": 12, "player_id": "0bca3ab6-6f5f-4ba4-8525-b958523548e0"}, {"rank": 5, "value": 0.333, "nickname": "Emma", "n_matches": 3, "player_id": "a435c102-0bdc-449e-ad56-727e42975cb7"}, {"rank": 6, "value": 0.333, "nickname": "Bob", "n_matches": 14, "player_id": "2aebbb9b-7461-4489-a135-6f61c9bf9643"}, {"rank": 7, "value": 0.25, "nickname": "Eve", "n_matches": 10, "player_id": "057366ea-f970-414f-b1b1-6c419a14d5a3"}]}, "defense_win_rate": {"name": "Defense Win Rate", "entries": [{"rank": 1, "value": 0.667, "nickname": "Eve", "n_matches": 10, "player_id": "057366ea-f970-414f-b1b1-6c419a14d5a3"}, {"rank": 2, "value": 0.625, "nickname": "Frank", "n_matches": 13, "player_id": "c4e1a678-733e-472a-a617-1731955c67c9"}, {"rank": 3, "value": 0.5, "nickname": "Alice", "n_matches": 12, "player_id": "0bca3ab6-6f5f-4ba4-8525-b958523548e0"}, {"rank": 4, "value": 0.429, "nickname": "Charlie", "n_matches": 11, "player_id": "fc83e69d-2909-4934-9ac2-dc0c91524bdb"}, {"rank": 5, "value": 0.4, "nickname": "Diana", "n_matches": 11, "player_id": "3aa26a43-1a89-4cd5-8dd3-22dee1537006"}, {"rank": 6, "value": 0.2, "nickname": "Bob", "n_matches": 14, "player_id": "2aebbb9b-7461-4489-a135-6f61c9bf9643"}, {"rank": 7, "value": 0, "nickname": "Emma", "n_matches": 3, "player_id": "a435c102-0bdc-449e-ad56-727e42975cb7"}]}, "gamelles_received": {"name": "Gamelles Received", "entries": [{"rank": 1, "value": 0, "nickname": "Eve", "n_matches": 10, "player_id": "057366ea-f970-414f-b1b1-6c419a14d5a3"}, {"rank": 2, "value": 0, "nickname": "Emma", "n_matches": 3, "player_id": "a435c102-0bdc-449e-ad56-727e42975cb7"}, {"rank": 3, "value": 0, "nickname": "Frank", "n_matches": 13, "player_id": "c4e1a678-733e-472a-a617-1731955c67c9"}, {"rank": 4, "value": 0, "nickname": "Charlie", "n_matches": 11, "player_id": "fc83e69d-2909-4934-9ac2-dc0c91524bdb"}, {"rank": 5, "value": 2, "nickname": "Alice", "n_matches": 12, "player_id": "0bca3ab6-6f5f-4ba4-8525-b958523548e0"}, {"rank": 6, "value": 3, "nickname": "Bob", "n_matches": 14, "player_id": "2aebbb9b-7461-4489-a135-6f61c9bf9643"}, {"rank": 7, "value": 3, "nickname": "Diana", "n_matches": 11, "player_id": "3aa26a43-1a89-4cd5-8dd3-22dee1537006"}]}, "gamelles_delivered": {"name": "Gamelles Delivered", "entries": [{"rank": 1, "value": 4, "nickname": "Charlie", "n_matches": 11, "player_id": "fc83e69d-2909-4934-9ac2-dc0c91524bdb"}, {"rank": 2, "value": 4, "nickname": "Eve", "n_matches": 10, "player_id": "057366ea-f970-414f-b1b1-6c419a14d5a3"}, {"rank": 3, "value": 0, "nickname": "Frank", "n_matches": 13, "player_id": "c4e1a678-733e-472a-a617-1731955c67c9"}, {"rank": 4, "value": 0, "nickname": "Emma", "n_matches": 3, "player_id": "a435c102-0bdc-449e-ad56-727e42975cb7"}, {"rank": 5, "value": 0, "nickname": "Diana", "n_matches": 11, "player_id": "3aa26a43-1a89-4cd5-8dd3-22dee1537006"}, {"rank": 6, "value": 0, "nickname": "Bob", "n_matches": 14, "player_id": "2aebbb9b-7461-4489-a135-6f61c9bf9643"}, {"rank": 7, "value": 0, "nickname": "Alice", "n_matches": 12, "player_id": "0bca3ab6-6f5f-4ba4-8525-b958523548e0"}]}}	2026-01-28 15:00:55.229734+00	3295ad848a862e75b5bf96b97e8350868e3c50f481c46ddbb1556c151a67d0f3
72594cf3-82e6-4144-8470-78696cdac96e	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	synergy	v1	{"best_duos": [{"wins": 3, "losses": 1, "win_rate": 0.75, "n_matches": 4, "player1_id": "c4e1a678-733e-472a-a617-1731955c67c9", "player2_id": "fc83e69d-2909-4934-9ac2-dc0c91524bdb", "player1_nickname": "Frank", "player2_nickname": "Charlie"}, {"wins": 2, "losses": 1, "win_rate": 0.6666666666666666, "n_matches": 3, "player1_id": "0bca3ab6-6f5f-4ba4-8525-b958523548e0", "player2_id": "3aa26a43-1a89-4cd5-8dd3-22dee1537006", "player1_nickname": "Alice", "player2_nickname": "Diana"}, {"wins": 1, "losses": 1, "win_rate": 0.5, "n_matches": 2, "player1_id": "057366ea-f970-414f-b1b1-6c419a14d5a3", "player2_id": "2aebbb9b-7461-4489-a135-6f61c9bf9643", "player1_nickname": "Eve", "player2_nickname": "Bob"}, {"wins": 1, "losses": 1, "win_rate": 0.5, "n_matches": 2, "player1_id": "3aa26a43-1a89-4cd5-8dd3-22dee1537006", "player2_id": "fc83e69d-2909-4934-9ac2-dc0c91524bdb", "player1_nickname": "Diana", "player2_nickname": "Charlie"}, {"wins": 1, "losses": 1, "win_rate": 0.5, "n_matches": 2, "player1_id": "057366ea-f970-414f-b1b1-6c419a14d5a3", "player2_id": "c4e1a678-733e-472a-a617-1731955c67c9", "player1_nickname": "Eve", "player2_nickname": "Frank"}, {"wins": 1, "losses": 1, "win_rate": 0.5, "n_matches": 2, "player1_id": "0bca3ab6-6f5f-4ba4-8525-b958523548e0", "player2_id": "c4e1a678-733e-472a-a617-1731955c67c9", "player1_nickname": "Alice", "player2_nickname": "Frank"}, {"wins": 1, "losses": 2, "win_rate": 0.3333333333333333, "n_matches": 3, "player1_id": "2aebbb9b-7461-4489-a135-6f61c9bf9643", "player2_id": "3aa26a43-1a89-4cd5-8dd3-22dee1537006", "player1_nickname": "Bob", "player2_nickname": "Diana"}, {"wins": 0, "losses": 2, "win_rate": 0.0, "n_matches": 2, "player1_id": "057366ea-f970-414f-b1b1-6c419a14d5a3", "player2_id": "0bca3ab6-6f5f-4ba4-8525-b958523548e0", "player1_nickname": "Eve", "player2_nickname": "Alice"}], "worst_duos": [{"wins": 0, "losses": 2, "win_rate": 0.0, "n_matches": 2, "player1_id": "057366ea-f970-414f-b1b1-6c419a14d5a3", "player2_id": "0bca3ab6-6f5f-4ba4-8525-b958523548e0", "player1_nickname": "Eve", "player2_nickname": "Alice"}, {"wins": 1, "losses": 2, "win_rate": 0.3333333333333333, "n_matches": 3, "player1_id": "2aebbb9b-7461-4489-a135-6f61c9bf9643", "player2_id": "3aa26a43-1a89-4cd5-8dd3-22dee1537006", "player1_nickname": "Bob", "player2_nickname": "Diana"}, {"wins": 1, "losses": 1, "win_rate": 0.5, "n_matches": 2, "player1_id": "057366ea-f970-414f-b1b1-6c419a14d5a3", "player2_id": "2aebbb9b-7461-4489-a135-6f61c9bf9643", "player1_nickname": "Eve", "player2_nickname": "Bob"}, {"wins": 1, "losses": 1, "win_rate": 0.5, "n_matches": 2, "player1_id": "3aa26a43-1a89-4cd5-8dd3-22dee1537006", "player2_id": "fc83e69d-2909-4934-9ac2-dc0c91524bdb", "player1_nickname": "Diana", "player2_nickname": "Charlie"}, {"wins": 1, "losses": 1, "win_rate": 0.5, "n_matches": 2, "player1_id": "057366ea-f970-414f-b1b1-6c419a14d5a3", "player2_id": "c4e1a678-733e-472a-a617-1731955c67c9", "player1_nickname": "Eve", "player2_nickname": "Frank"}, {"wins": 1, "losses": 1, "win_rate": 0.5, "n_matches": 2, "player1_id": "0bca3ab6-6f5f-4ba4-8525-b958523548e0", "player2_id": "c4e1a678-733e-472a-a617-1731955c67c9", "player1_nickname": "Alice", "player2_nickname": "Frank"}, {"wins": 2, "losses": 1, "win_rate": 0.6666666666666666, "n_matches": 3, "player1_id": "0bca3ab6-6f5f-4ba4-8525-b958523548e0", "player2_id": "3aa26a43-1a89-4cd5-8dd3-22dee1537006", "player1_nickname": "Alice", "player2_nickname": "Diana"}, {"wins": 3, "losses": 1, "win_rate": 0.75, "n_matches": 4, "player1_id": "c4e1a678-733e-472a-a617-1731955c67c9", "player2_id": "fc83e69d-2909-4934-9ac2-dc0c91524bdb", "player1_nickname": "Frank", "player2_nickname": "Charlie"}]}	2026-01-28 15:00:55.229734+00	3295ad848a862e75b5bf96b97e8350868e3c50f481c46ddbb1556c151a67d0f3
dd488704-9400-43f8-814e-3a0bd5fbaf83	4fe0eb2d-2c17-46da-bd0c-f15d33b35dd1	e3d617ad-e920-419f-a3e5-6e0b4de453d6	matchups	v1	[{"n_matches": 2, "player1_id": "0bca3ab6-6f5f-4ba4-8525-b958523548e0", "player2_id": "c4e1a678-733e-472a-a617-1731955c67c9", "player1_wins": 0, "player2_wins": 2, "player1_nickname": "Alice", "player2_nickname": "Frank"}, {"n_matches": 2, "player1_id": "057366ea-f970-414f-b1b1-6c419a14d5a3", "player2_id": "2aebbb9b-7461-4489-a135-6f61c9bf9643", "player1_wins": 2, "player2_wins": 0, "player1_nickname": "Eve", "player2_nickname": "Bob"}, {"n_matches": 2, "player1_id": "0bca3ab6-6f5f-4ba4-8525-b958523548e0", "player2_id": "2aebbb9b-7461-4489-a135-6f61c9bf9643", "player1_wins": 2, "player2_wins": 0, "player1_nickname": "Alice", "player2_nickname": "Bob"}]	2026-01-28 15:00:55.229734+00	3295ad848a862e75b5bf96b97e8350868e3c50f481c46ddbb1556c151a67d0f3
3a3df134-5faf-473a-a3c8-3c7b9b684f0e	5c900756-8c86-476c-afaf-5115705dccd8	92d9eeac-f264-4b8f-8b3b-990a929af9f3	leaderboards	v1	{"elo": {"name": "Elo Rating", "entries": [{"rank": 1, "value": 1212, "nickname": "Test", "n_matches": 3, "player_id": "40e3f3ae-b802-4671-be6c-1a5e889ac02c"}, {"rank": 2, "value": 1188, "nickname": "Florian", "n_matches": 3, "player_id": "3fa970ed-06c8-4856-bd6a-bdcbc8afde04"}]}, "win_rate": {"name": "Win Rate", "entries": [{"rank": 1, "value": 0.667, "nickname": "Test", "n_matches": 3, "player_id": "40e3f3ae-b802-4671-be6c-1a5e889ac02c"}, {"rank": 2, "value": 0.333, "nickname": "Florian", "n_matches": 3, "player_id": "3fa970ed-06c8-4856-bd6a-bdcbc8afde04"}]}, "current_streak": {"name": "Current Streak", "entries": [{"rank": 1, "value": 1, "nickname": "Florian", "n_matches": 3, "player_id": "3fa970ed-06c8-4856-bd6a-bdcbc8afde04"}, {"rank": 2, "value": -1, "nickname": "Test", "n_matches": 3, "player_id": "40e3f3ae-b802-4671-be6c-1a5e889ac02c"}]}, "attack_win_rate": {"name": "Attack Win Rate", "entries": [{"rank": 1, "value": 1.0, "nickname": "Test", "n_matches": 3, "player_id": "40e3f3ae-b802-4671-be6c-1a5e889ac02c"}, {"rank": 2, "value": 0.333, "nickname": "Florian", "n_matches": 3, "player_id": "3fa970ed-06c8-4856-bd6a-bdcbc8afde04"}]}, "defense_win_rate": {"name": "Defense Win Rate", "entries": [{"rank": 1, "value": 0.0, "nickname": "Test", "n_matches": 3, "player_id": "40e3f3ae-b802-4671-be6c-1a5e889ac02c"}, {"rank": 2, "value": 0, "nickname": "Florian", "n_matches": 3, "player_id": "3fa970ed-06c8-4856-bd6a-bdcbc8afde04"}]}, "gamelles_received": {"name": "Gamelles Received", "entries": [{"rank": 1, "value": 0, "nickname": "Florian", "n_matches": 3, "player_id": "3fa970ed-06c8-4856-bd6a-bdcbc8afde04"}, {"rank": 2, "value": 0, "nickname": "Test", "n_matches": 3, "player_id": "40e3f3ae-b802-4671-be6c-1a5e889ac02c"}]}, "gamelles_delivered": {"name": "Gamelles Delivered", "entries": [{"rank": 1, "value": 0, "nickname": "Test", "n_matches": 3, "player_id": "40e3f3ae-b802-4671-be6c-1a5e889ac02c"}, {"rank": 2, "value": 0, "nickname": "Florian", "n_matches": 3, "player_id": "3fa970ed-06c8-4856-bd6a-bdcbc8afde04"}]}}	2026-01-28 22:13:08.513792+00	a677bdd4ccc6024cd2e60925d4662c51381329825704d0c251b146d9eeb927db
d71077c9-b026-4517-9c55-3abbeac9f192	5c900756-8c86-476c-afaf-5115705dccd8	92d9eeac-f264-4b8f-8b3b-990a929af9f3	synergy	v1	{"best_duos": [], "worst_duos": []}	2026-01-28 22:13:08.513792+00	a677bdd4ccc6024cd2e60925d4662c51381329825704d0c251b146d9eeb927db
1ebc5756-806a-4082-9016-3b5de01e05c1	5c900756-8c86-476c-afaf-5115705dccd8	92d9eeac-f264-4b8f-8b3b-990a929af9f3	matchups	v1	[{"n_matches": 3, "player1_id": "3fa970ed-06c8-4856-bd6a-bdcbc8afde04", "player2_id": "40e3f3ae-b802-4671-be6c-1a5e889ac02c", "player1_wins": 1, "player2_wins": 2, "player1_nickname": "Florian", "player2_nickname": "Test"}]	2026-01-28 22:13:08.513792+00	a677bdd4ccc6024cd2e60925d4662c51381329825704d0c251b146d9eeb927db
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: foospulse
--

COPY public.users (id, email, password_hash, display_name, created_at, updated_at) FROM stdin;
56ac7a3c-176c-4ed9-ab45-5d3fea8d9845	demo@example.com	$2b$12$MjXqOkBgfUGTyQZdQvQP5.MylaZeIzvagB21z6OIbUAGm2X8qxknO	Demo User	2026-01-27 15:55:03.162004+00	2026-01-27 15:55:03.162014+00
5f18dda4-73b9-4ffd-a723-6dd2332f3f0e	test@example.com	$2b$12$6ZyLTpCpo2F1yadW41y2Q.eCH3sQzCA65QGZvIr4QKnNkbzSc7SxG	Test User	2026-01-27 16:02:02.344394+00	2026-01-27 16:02:02.344397+00
97d46e6a-a269-4047-9cca-fd55e4b51da9	test_5351997e@example.com	$2b$12$FPJ.hOmi7q8OWWlj3rOk4.6ys.t5O0Uc7Bjq3XcMta5brM.edwuea	Test User	2026-01-27 17:44:47.639696+00	2026-01-27 17:44:47.639701+00
6f62e6b4-4cf2-48bd-a634-0cc114ddbdef	curl_test@example.com	$2b$12$zvt6/mk0wi1CCOcNiAj0OuxBauyfuaPDN1EJZemhXzehfxD1CSFoa	Curl Test	2026-01-27 17:44:53.187587+00	2026-01-27 17:44:53.187591+00
6b0efed5-c349-4c9c-8145-f3fba3e9fb5e	test_a8926807@example.com	$2b$12$qamLVj3RPiTKJSA6NTxeUuEJKqNLyEBurvFg.4V2e2u3b0bTmp7MW	Test User	2026-01-27 17:45:07.827129+00	2026-01-27 17:45:07.827133+00
a9198fbd-b4ac-4166-bbad-00ce37d019c6	test_b1d7a7e0@example.com	$2b$12$up0uCMLRRJYOP0dTagAcMOprEsyAF9tKWt3Kz/EXpJ5LwP8Ah2ayK	Test User	2026-01-27 18:08:12.696743+00	2026-01-27 18:08:12.696746+00
20cc17bd-7b52-43f5-8043-9e1e2b98e129	test_f7945236@example.com	$2b$12$XQWkk8iq4iZ5AxUoS/OHIO5e64esVdXpXbHmHtpVnimXkxmgt9egu	Test User	2026-01-28 10:41:12.485741+00	2026-01-28 10:41:12.485751+00
68bee76a-03e6-4111-aa40-c928b1d325d7	test_787ec1da@example.com	$2b$12$XckxNmrmjroUP7D0LAI.8u1X9GTXZMvhCg7zS3miyrjMcGYeJ/DBm	Test User	2026-01-28 10:42:53.758561+00	2026-01-28 10:42:53.758571+00
f4612f7b-c25e-4542-ad22-a7d304724f50	test_179d3299@example.com	$2b$12$9aRZe6kBy9j../X.h1BlPOWLH9vZOtnq.L5JlSD974r22XWOWGdB6	Test User	2026-01-28 10:45:08.991456+00	2026-01-28 10:45:08.99146+00
8636f946-5791-4652-92f4-6d3c9d428a93	test_9c6149fe@example.com	$2b$12$UTVcL1TqLhZ7uFIy3ZOQlumjUp97LAGIvbbu6xIXjotsN3V5U5gSe	Test User	2026-01-28 10:46:26.876561+00	2026-01-28 10:46:26.876565+00
b786bbe1-1bc9-4e36-bb07-8ed33e265bbf	test_28cf6ab6@example.com	$2b$12$LVt5F0zeIbMaqB6XcGelZ.UGVxD5rTSXLHcOwYQTol6tx1.22dgCu	Test User	2026-01-28 10:47:31.082659+00	2026-01-28 10:47:31.082663+00
9a79dcdb-6761-4561-a4c7-2919e6d715b0	test_4048d1f2@example.com	$2b$12$O4rP2FQQ5gZZlXPUwhYgheOugoJfLtJ0qTYPph5lKZwrg.dC9.rE2	Test User	2026-01-28 10:50:26.900453+00	2026-01-28 10:50:26.900464+00
b513b806-3418-4c15-805b-a8f386db9068	test_97e75cfa@example.com	$2b$12$DiaORr47QxVQ8/XgJbUuou3y/8RdrqrIHgv2pSPLaEBxxhyvMJq1S	Test User	2026-01-28 10:51:50.261227+00	2026-01-28 10:51:50.261239+00
2e86a50d-af61-4fe8-adca-0e310055821e	test_cdc2934d@example.com	$2b$12$5Uq5hKLSsX4w3kmwbehs6OJqC9vt7ojjkl4Ywln.v9yhvpZ8Hce/S	Test User	2026-01-28 10:53:04.050716+00	2026-01-28 10:53:04.050728+00
88ec2137-7af9-40ec-b475-81eaff58614c	test_3e4c38a5@example.com	$2b$12$Xbl2JIcR5bgNHWhB/JxVZO9fUQuaUWq3OONy9qeSjyBOWkr9qfgGG	Test User	2026-01-28 10:54:06.98+00	2026-01-28 10:54:06.980004+00
9abc693e-974d-4649-b816-fac0290441d2	flo.loeser@gmail.com	$2b$12$XtjEe.rGYiM1pBOab0WHw.aNh2lDc.aMsusSoFIRGZ3BtYDVyaI8q	Florian	2026-01-28 19:37:49.431858+00	2026-01-28 19:37:49.431861+00
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: foospulse
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 6, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: artifacts artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.artifacts
    ADD CONSTRAINT artifacts_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: league_members league_members_pkey; Type: CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.league_members
    ADD CONSTRAINT league_members_pkey PRIMARY KEY (id);


--
-- Name: leagues leagues_pkey; Type: CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.leagues
    ADD CONSTRAINT leagues_pkey PRIMARY KEY (id);


--
-- Name: live_match_session_events live_match_session_events_pkey; Type: CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.live_match_session_events
    ADD CONSTRAINT live_match_session_events_pkey PRIMARY KEY (id);


--
-- Name: live_match_session_players live_match_session_players_pkey; Type: CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.live_match_session_players
    ADD CONSTRAINT live_match_session_players_pkey PRIMARY KEY (id);


--
-- Name: live_match_sessions live_match_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.live_match_sessions
    ADD CONSTRAINT live_match_sessions_pkey PRIMARY KEY (id);


--
-- Name: match_events match_events_pkey; Type: CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.match_events
    ADD CONSTRAINT match_events_pkey PRIMARY KEY (id);


--
-- Name: match_players match_players_pkey; Type: CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.match_players
    ADD CONSTRAINT match_players_pkey PRIMARY KEY (id);


--
-- Name: matches matches_pkey; Type: CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_pkey PRIMARY KEY (id);


--
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (id);


--
-- Name: rating_snapshots rating_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.rating_snapshots
    ADD CONSTRAINT rating_snapshots_pkey PRIMARY KEY (id);


--
-- Name: seasons seasons_pkey; Type: CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.seasons
    ADD CONSTRAINT seasons_pkey PRIMARY KEY (id);


--
-- Name: stats_snapshots stats_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.stats_snapshots
    ADD CONSTRAINT stats_snapshots_pkey PRIMARY KEY (id);


--
-- Name: players uq_player_league_nickname; Type: CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT uq_player_league_nickname UNIQUE (league_id, nickname);


--
-- Name: rating_snapshots uq_rating_player_match_mode; Type: CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.rating_snapshots
    ADD CONSTRAINT uq_rating_player_match_mode UNIQUE (player_id, as_of_match_id, mode);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_artifacts_league_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_artifacts_league_id ON public.artifacts USING btree (league_id);


--
-- Name: ix_artifacts_season_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_artifacts_season_id ON public.artifacts USING btree (season_id);


--
-- Name: ix_audit_logs_action; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: ix_audit_logs_actor_user_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_audit_logs_actor_user_id ON public.audit_logs USING btree (actor_user_id);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: ix_audit_logs_entity_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_audit_logs_entity_id ON public.audit_logs USING btree (entity_id);


--
-- Name: ix_audit_logs_league_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_audit_logs_league_id ON public.audit_logs USING btree (league_id);


--
-- Name: ix_league_members_league_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_league_members_league_id ON public.league_members USING btree (league_id);


--
-- Name: ix_leagues_invite_code; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE UNIQUE INDEX ix_leagues_invite_code ON public.leagues USING btree (invite_code);


--
-- Name: ix_leagues_slug; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE UNIQUE INDEX ix_leagues_slug ON public.leagues USING btree (slug);


--
-- Name: ix_live_match_session_events_session_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_live_match_session_events_session_id ON public.live_match_session_events USING btree (session_id);


--
-- Name: ix_live_match_session_players_session_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_live_match_session_players_session_id ON public.live_match_session_players USING btree (session_id);


--
-- Name: ix_live_match_sessions_league_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_live_match_sessions_league_id ON public.live_match_sessions USING btree (league_id);


--
-- Name: ix_live_match_sessions_season_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_live_match_sessions_season_id ON public.live_match_sessions USING btree (season_id);


--
-- Name: ix_live_match_sessions_share_token; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE UNIQUE INDEX ix_live_match_sessions_share_token ON public.live_match_sessions USING btree (share_token);


--
-- Name: ix_match_events_match_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_match_events_match_id ON public.match_events USING btree (match_id);


--
-- Name: ix_match_players_match_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_match_players_match_id ON public.match_players USING btree (match_id);


--
-- Name: ix_match_players_player_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_match_players_player_id ON public.match_players USING btree (player_id);


--
-- Name: ix_matches_league_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_matches_league_id ON public.matches USING btree (league_id);


--
-- Name: ix_matches_season_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_matches_season_id ON public.matches USING btree (season_id);


--
-- Name: ix_players_league_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_players_league_id ON public.players USING btree (league_id);


--
-- Name: ix_rating_snapshots_league_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_rating_snapshots_league_id ON public.rating_snapshots USING btree (league_id);


--
-- Name: ix_rating_snapshots_player_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_rating_snapshots_player_id ON public.rating_snapshots USING btree (player_id);


--
-- Name: ix_rating_snapshots_season_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_rating_snapshots_season_id ON public.rating_snapshots USING btree (season_id);


--
-- Name: ix_seasons_league_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_seasons_league_id ON public.seasons USING btree (league_id);


--
-- Name: ix_stats_snapshots_league_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_stats_snapshots_league_id ON public.stats_snapshots USING btree (league_id);


--
-- Name: ix_stats_snapshots_season_id; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE INDEX ix_stats_snapshots_season_id ON public.stats_snapshots USING btree (season_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: foospulse
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: artifacts artifacts_created_by_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.artifacts
    ADD CONSTRAINT artifacts_created_by_player_id_fkey FOREIGN KEY (created_by_player_id) REFERENCES public.players(id);


--
-- Name: artifacts artifacts_league_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.artifacts
    ADD CONSTRAINT artifacts_league_id_fkey FOREIGN KEY (league_id) REFERENCES public.leagues(id);


--
-- Name: artifacts artifacts_season_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.artifacts
    ADD CONSTRAINT artifacts_season_id_fkey FOREIGN KEY (season_id) REFERENCES public.seasons(id);


--
-- Name: audit_logs audit_logs_actor_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_actor_player_id_fkey FOREIGN KEY (actor_player_id) REFERENCES public.players(id);


--
-- Name: audit_logs audit_logs_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id);


--
-- Name: audit_logs audit_logs_league_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_league_id_fkey FOREIGN KEY (league_id) REFERENCES public.leagues(id);


--
-- Name: league_members league_members_league_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.league_members
    ADD CONSTRAINT league_members_league_id_fkey FOREIGN KEY (league_id) REFERENCES public.leagues(id);


--
-- Name: league_members league_members_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.league_members
    ADD CONSTRAINT league_members_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id);


--
-- Name: league_members league_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.league_members
    ADD CONSTRAINT league_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: leagues leagues_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.leagues
    ADD CONSTRAINT leagues_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: live_match_session_events live_match_session_events_against_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.live_match_session_events
    ADD CONSTRAINT live_match_session_events_against_player_id_fkey FOREIGN KEY (against_player_id) REFERENCES public.players(id);


--
-- Name: live_match_session_events live_match_session_events_by_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.live_match_session_events
    ADD CONSTRAINT live_match_session_events_by_player_id_fkey FOREIGN KEY (by_player_id) REFERENCES public.players(id);


--
-- Name: live_match_session_events live_match_session_events_recorded_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.live_match_session_events
    ADD CONSTRAINT live_match_session_events_recorded_by_user_id_fkey FOREIGN KEY (recorded_by_user_id) REFERENCES public.users(id);


--
-- Name: live_match_session_events live_match_session_events_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.live_match_session_events
    ADD CONSTRAINT live_match_session_events_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.live_match_sessions(id) ON DELETE CASCADE;


--
-- Name: live_match_session_players live_match_session_players_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.live_match_session_players
    ADD CONSTRAINT live_match_session_players_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id);


--
-- Name: live_match_session_players live_match_session_players_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.live_match_session_players
    ADD CONSTRAINT live_match_session_players_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.live_match_sessions(id) ON DELETE CASCADE;


--
-- Name: live_match_sessions live_match_sessions_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.live_match_sessions
    ADD CONSTRAINT live_match_sessions_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: live_match_sessions live_match_sessions_finalized_match_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.live_match_sessions
    ADD CONSTRAINT live_match_sessions_finalized_match_id_fkey FOREIGN KEY (finalized_match_id) REFERENCES public.matches(id);


--
-- Name: live_match_sessions live_match_sessions_league_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.live_match_sessions
    ADD CONSTRAINT live_match_sessions_league_id_fkey FOREIGN KEY (league_id) REFERENCES public.leagues(id);


--
-- Name: live_match_sessions live_match_sessions_season_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.live_match_sessions
    ADD CONSTRAINT live_match_sessions_season_id_fkey FOREIGN KEY (season_id) REFERENCES public.seasons(id);


--
-- Name: match_events match_events_against_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.match_events
    ADD CONSTRAINT match_events_against_player_id_fkey FOREIGN KEY (against_player_id) REFERENCES public.players(id);


--
-- Name: match_events match_events_by_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.match_events
    ADD CONSTRAINT match_events_by_player_id_fkey FOREIGN KEY (by_player_id) REFERENCES public.players(id);


--
-- Name: match_events match_events_match_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.match_events
    ADD CONSTRAINT match_events_match_id_fkey FOREIGN KEY (match_id) REFERENCES public.matches(id);


--
-- Name: match_players match_players_match_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.match_players
    ADD CONSTRAINT match_players_match_id_fkey FOREIGN KEY (match_id) REFERENCES public.matches(id);


--
-- Name: match_players match_players_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.match_players
    ADD CONSTRAINT match_players_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id);


--
-- Name: matches matches_created_by_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_created_by_player_id_fkey FOREIGN KEY (created_by_player_id) REFERENCES public.players(id);


--
-- Name: matches matches_league_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_league_id_fkey FOREIGN KEY (league_id) REFERENCES public.leagues(id);


--
-- Name: matches matches_season_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_season_id_fkey FOREIGN KEY (season_id) REFERENCES public.seasons(id);


--
-- Name: players players_league_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_league_id_fkey FOREIGN KEY (league_id) REFERENCES public.leagues(id);


--
-- Name: players players_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: rating_snapshots rating_snapshots_as_of_match_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.rating_snapshots
    ADD CONSTRAINT rating_snapshots_as_of_match_id_fkey FOREIGN KEY (as_of_match_id) REFERENCES public.matches(id);


--
-- Name: rating_snapshots rating_snapshots_league_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.rating_snapshots
    ADD CONSTRAINT rating_snapshots_league_id_fkey FOREIGN KEY (league_id) REFERENCES public.leagues(id);


--
-- Name: rating_snapshots rating_snapshots_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.rating_snapshots
    ADD CONSTRAINT rating_snapshots_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id);


--
-- Name: rating_snapshots rating_snapshots_season_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.rating_snapshots
    ADD CONSTRAINT rating_snapshots_season_id_fkey FOREIGN KEY (season_id) REFERENCES public.seasons(id);


--
-- Name: seasons seasons_league_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.seasons
    ADD CONSTRAINT seasons_league_id_fkey FOREIGN KEY (league_id) REFERENCES public.leagues(id);


--
-- Name: stats_snapshots stats_snapshots_league_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.stats_snapshots
    ADD CONSTRAINT stats_snapshots_league_id_fkey FOREIGN KEY (league_id) REFERENCES public.leagues(id);


--
-- Name: stats_snapshots stats_snapshots_season_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: foospulse
--

ALTER TABLE ONLY public.stats_snapshots
    ADD CONSTRAINT stats_snapshots_season_id_fkey FOREIGN KEY (season_id) REFERENCES public.seasons(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: foospulse
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict UTOKPyfNgzfBUwxw72FKbScSGtrS3dpMLLyT4sVtlnLpugghozPvZfYFu9wNgt0

